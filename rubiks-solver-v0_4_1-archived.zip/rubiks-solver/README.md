# Rubik's Cube Solver

Веб-приложение: фото/камера → распознавание граней → расчёт сборки.

Текущая версия: **0.4.1** (багфикс: тёмная картинка с камеры, неоднозначная инструкция поворота на десктопных веб-камерах — см. CHANGELOG) — решатель полностью готов и протестирован (headless), плюс распознавание цвета, мастер съёмки и редактор развёртки с валидатором собираемости. Метод Коциембы (two-phase): ~23 хода в среднем, ~50мс на решение.

Структура и план разработки — в [HANDOFF.md](./HANDOFF.md), история решений — в [CHANGELOG.md](./CHANGELOG.md).

## Что уже есть
- `js/engine.js` — модель кубика Рубика (54 наклейки, повороты граней).
- `js/kociemba/coordinates.js` — координаты метода Коциембы.
- `js/kociemba/tables.js` — загрузка/декодирование таблиц (браузер + Node.js).
- `data/tables/*.json` — готовые move/pruning-таблицы (~7.5 МБ).
- `js/kociemba/idastar.js`, `phase1.js`, `phase2.js` — IDA*-поиск.
- `js/kociemba/moveOptimizer.js` — схлопывание избыточных ходов.
- `js/kociemba/solve.js` — полный решатель: кубик → список ходов, с проверкой корректности.
- `js/colorDetect.js` — распознавание цвета 54 наклеек по 6 фото граней (эталон — центр грани, расстояние в CIE Lab), выдаёт facelets прямо в формате `cubeFromFacelets` + уверенность по каждой наклейке.
- `js/capture.js` — мастер съёмки "2 хвата, 6 кадров": протокол шагов, сетка-гид, состояние мастера; отдаёт результат прямо в `colorDetect.js`.
- `js/validator.js` — проверка собираемости facelets (счётчики цветов, физическая реальность каждой фигуры, чётности) с понятными сообщениями об ошибках.
- `js/netEditor.js` — редактор развёртки: цикл цвета по клику, поворот грани целиком, живая валидация поверх `validator.js`.
- `index.html` + `css/styles.css` + `js/captureDemo.js` — рабочий тестовый стенд: камера/файл → распознанные цвета на редактируемой развёртке-кресте с подсказками валидатора.

## Как открыть в браузере
Откройте `index.html` через локальный сервер (не `file://` — камера и `getUserMedia` требуют `https`/`localhost`), например:
```
npx http-server . -p 8080
```
и перейдите на `http://localhost:8080`. Без камеры тоже работает — кнопка «Файл» принимает фото граней.

## Пример использования (headless)
```js
import * as E from './js/engine.js';
import { loadTables, nodeFetchJson } from './js/kociemba/tables.js';
import { solveCube } from './js/kociemba/solve.js';

const tables = await loadTables(nodeFetchJson('./data/tables'));
const cube = E.cubeFromFacelets(myFacelets); // из распознавания камеры
const result = solveCube(cube, tables);
console.log(result.solved, result.moves); // true, ['R', "U'", 'F2', ...]
```

## Пример использования colorDetect.js
```js
import { detectCubeColors } from './js/colorDetect.js';
import * as E from './js/engine.js';

// facesImages: { U, R, F, D, L, B } — ImageData с камеры/canvas (по одной на грань)
const { facelets, confidence } = detectCubeColors(facesImages);
const cube = E.cubeFromFacelets(facelets); // напрямую в решатель
```

## Запуск тестов
```
npm test
```

## Пересборка таблиц (если понадобится)
```
npm run build-tables
```

## Дальше по плану
Этап 0.5.0 — плеер решения + сборка приложения целиком (`solutionPlayer.js` + `main.js`, заменит временный `captureDemo.js`), см. HANDOFF.md.
