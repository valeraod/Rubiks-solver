// Тест чистых функций (flood fill, minAreaRect, classifyColor)
// из script.js без реального браузера/canvas — через мок document,
// который "проглатывает" любые обращения (getElementById и т.п.),
// чтобы верхнеуровневые DOM-ссылки в script.js не падали.

const fs = require('fs');
const { PNG } = require('pngjs');
const vm = require('vm');

function makeDummy() {
  const handler = {
    get(target, prop) {
      if (prop === 'children') return [];
      if (prop === 'style') return makeDummy();
      if (prop === 'classList') return { add(){}, remove(){}, toggle(){} };
      if (prop === 'toString') return () => '[dummy]';
      return function () { return makeDummy(); };
    },
    set() { return true; },
  };
  return new Proxy(function () {}, handler);
}

const sandbox = {
  document: {
    getElementById: () => makeDummy(),
    createElement: () => makeDummy(),
  },
  console,
  Math,
};
vm.createContext(sandbox);

let src = fs.readFileSync('js/script.js', 'utf8');
// не даём верхнеуровневым initSwatchGrid()/wireEvents() выполниться —
// достаточно закомментировать последние вызовы, они всё равно тестовому
// коду не нужны (мы вызываем функции напрямую)
src = src.replace('initSwatchGrid();\ninitFaceCross();\nwireEvents();', '// disabled for test');
src = src.replace("wireNetEvents();\nselectFace('F');", '// disabled for test');

vm.runInContext(src, sandbox, { filename: 'script.js' });

// ---- загрузка PNG в ImageData-подобный объект ----
function loadImageData(path) {
  const png = PNG.sync.read(fs.readFileSync(path));
  return { data: png.data, width: png.width, height: png.height };
}

function test(path, clickX, clickY, upX, upY) {
  const imgData = loadImageData(path);
  const tolerance = 42;
  const ratio = 0.85;
  const maxBound = Math.min(imgData.width, imgData.height) * 0.35;

  const flood = sandbox.floodFill(imgData, clickX, clickY, tolerance, maxBound);
  console.log(`\n[${path}] center click=(${clickX},${clickY}) flood points=${flood.points.length}`);

  const rect = sandbox.minAreaRect(flood.points);
  console.log(`  rect: cx=${rect.cx.toFixed(1)} cy=${rect.cy.toFixed(1)} w=${rect.width.toFixed(1)} h=${rect.height.toFixed(1)} angle(deg)=${(rect.angle*180/Math.PI).toFixed(1)}`);

  // логика из handleUpClick
  const angle = rect.angle;
  const axisA = [Math.cos(angle), Math.sin(angle)];
  const axisB = [-Math.sin(angle), Math.cos(angle)];
  const candidates = [axisA, [-axisA[0], -axisA[1]], axisB, [-axisB[0], -axisB[1]]];

  const dir = [upX - rect.cx, upY - rect.cy];
  const dirLen = Math.hypot(dir[0], dir[1]) || 1;
  const dirNorm = [dir[0] / dirLen, dir[1] / dirLen];

  let bestUp = candidates[0], bestDot = -Infinity;
  for (const c of candidates) {
    const dot = c[0]*dirNorm[0] + c[1]*dirNorm[1];
    if (dot > bestDot) { bestDot = dot; bestUp = c; }
  }
  const upVec = bestUp;
  const downVec = [-upVec[0], -upVec[1]];
  const rightVec = [-upVec[1], upVec[0]];

  const sizeAvg = (rect.width + rect.height) / 2;
  const pitch = sizeAvg / ratio;
  const patchHalf = Math.max(3, sizeAvg * 0.18);

  const grid = [];
  for (let rowOff = -1; rowOff <= 1; rowOff++) {
    const row = [];
    for (let colOff = -1; colOff <= 1; colOff++) {
      const px = rect.cx + colOff * pitch * rightVec[0] + rowOff * pitch * downVec[0];
      const py = rect.cy + colOff * pitch * rightVec[1] + rowOff * pitch * downVec[1];
      const color = sandbox.sampleMedianColor(imgData, px, py, patchHalf);
      const name = color ? sandbox.classifyColor(color.r, color.g, color.b) : '???';
      row.push(name);
    }
    grid.push(row);
  }
  console.log('  grid:');
  grid.forEach(r => console.log('   ', r.join(', ')));
  return grid;
}

// центр -- та же синяя наклейка; "верх" -- точка на верхней средней (красной) наклейке
const frontal = test('samples/frontal.png', 468, 664, 468, 390);
const tilted = test('samples/tilted.png', 485, 658, 376, 427);

const expected = [
  ['red', 'blue', 'red'],
  ['white', 'blue', 'white'],
  ['red', 'yellow', 'yellow'],
];

function matches(grid) {
  return JSON.stringify(grid) === JSON.stringify(expected);
}

console.log('\n=== ИТОГ ===');
console.log('frontal matches expected:', matches(frontal));
console.log('tilted matches expected: ', matches(tilted));
