// Тест логики мультиграневого сканирования: saveScannedFace/updateNetExport
// с более полноценным фейковым DOM (реально хранящим value/textContent),
// чтобы проверить сборку facelet-строки и валидацию без браузера.

const fs = require('fs');
const vm = require('vm');

function makeFakeElement() {
  return {
    style: {},
    classList: { add(){}, remove(){}, toggle(){}, contains(){ return false; } },
    dataset: {},
    children: [],
    hidden: false,
    value: '',
    textContent: '',
    innerHTML: '',
    className: '',
    appendChild(el) { this.children.push(el); return el; },
    remove() {},
    querySelector(sel) {
      const cls = sel.replace('.', '');
      return this.children.find(c => (c.className || '').includes(cls)) || null;
    },
    addEventListener() {},
    getContext() {
      return {
        drawImage(){}, clearRect(){}, getImageData(){ return { data: new Uint8ClampedArray(4), width:1, height:1 }; },
        beginPath(){}, moveTo(){}, lineTo(){}, closePath(){}, stroke(){}, fill(){},
        arc(){}, fillRect(){}, fillText(){}, measureText(){ return { width: 0 }; },
        save(){}, restore(){}, setLineDash(){},
      };
    },
  };
}

const elements = {};
function getElementById(id) {
  if (!elements[id]) elements[id] = makeFakeElement();
  return elements[id];
}

const sandbox = {
  document: {
    getElementById,
    createElement: () => makeFakeElement(),
  },
  console,
  Math,
  Object,
  navigator: { clipboard: { writeText: async () => {} } },
};
vm.createContext(sandbox);

const src = fs.readFileSync('js/script.js', 'utf8');
vm.runInContext(src, sandbox, { filename: 'script.js' });

function uniformGrid(color) {
  return [
    [{ name: color }, { name: color }, { name: color }],
    [{ name: color }, { name: color }, { name: color }],
    [{ name: color }, { name: color }, { name: color }],
  ];
}

// ---- тест 1: валидный решённый кубик ----
const scheme = { U: 'white', D: 'yellow', F: 'green', B: 'blue', L: 'orange', R: 'red' };
for (const label in scheme) {
  sandbox.saveScannedFace(label, uniformGrid(scheme[label]));
}

const faceletEl = elements['faceletString'];
const validationEl = elements['netValidation'];
const exportStateEl = elements['netExportState'];

console.log('facelet string:', faceletEl.value);
console.log('length:', faceletEl.value.length);
console.log('export state:', exportStateEl.textContent);
console.log('validation:', validationEl.textContent);

const expected = 'U'.repeat(9) + 'R'.repeat(9) + 'F'.repeat(9) + 'D'.repeat(9) + 'L'.repeat(9) + 'B'.repeat(9);
console.log('\nmatches expected order (URFDLB, 9 each):', faceletEl.value === expected);

// ---- тест 2: сломанный кубик (совпадающие центры L и R) ----
console.log('\n--- тест 2: совпадающие центры ---');
sandbox.saveScannedFace('R', uniformGrid('orange')); // теперь R и L оба "orange"
console.log('validation:', elements['netValidation'].textContent);
console.log('export state:', elements['netExportState'].textContent);

// ---- тест 3: неправильное количество (одна наклейка испорчена) ----
console.log('\n--- тест 3: одна наклейка другого цвета ---');
sandbox.saveScannedFace('R', uniformGrid('red'));
const brokenGrid = uniformGrid('red');
brokenGrid[0][0] = { name: 'blue' }; // одна наклейка ошибочно blue вместо red
sandbox.saveScannedFace('R', brokenGrid);
console.log('validation:', elements['netValidation'].textContent);
