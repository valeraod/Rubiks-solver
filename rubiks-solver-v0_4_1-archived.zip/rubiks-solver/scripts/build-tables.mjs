// build-tables.mjs
// Строит move-таблицы и pruning-таблицы для алгоритма Коциембы (two-phase)
// и сохраняет их как компактные JSON-файлы (base64 поверх typed arrays) в
// data/tables/. Запускается один раз в Node.js при разработке; в браузере
// эти файлы только загружаются (см. js/kociemba/tables.js).
//
// Корректность формулы композиции ходов (newPerm[s] = perm[basePerm[s]],
// newOri[s] = (ori[basePerm[s]] + baseOriDelta[s]) % base) проверена в
// песочнице против прямой симуляции engine.js на 30 случайных 20-ходовых
// последовательностях — совпадение полное. Также проверено, что 10 ходов
// фазы 2 сохраняют разбиение рёбер на "не экваториальные" (0..7) и
// "экваториальные" (8..11) — необходимое условие для координат фазы 2.

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import * as E from '../js/engine.js';
import * as C from '../js/kociemba/coordinates.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const OUT_DIR = path.join(__dirname, '..', 'data', 'tables');
fs.mkdirSync(OUT_DIR, { recursive: true });

const ALL_MOVES = [];
for (const f of ['U', 'D', 'L', 'R', 'F', 'B']) for (const m of ['', "'", '2']) ALL_MOVES.push(f + m);
const PHASE2_MOVES = ['U', "U'", 'U2', 'D', "D'", 'D2', 'L2', 'R2', 'F2', 'B2'];

function log(...args) { console.log('[build-tables]', ...args); }

// ---- Базовые преобразования (эффект каждого хода на собранном кубике) ----
function computeBaseTransforms(moves) {
  const cornerPerm = {}, cornerOriDelta = {}, edgePerm = {}, edgeOriDelta = {};
  for (const mv of moves) {
    const cube = E.newSolvedCube();
    E.applyMove(cube, mv);
    const c = C.readCorners(cube);
    cornerPerm[mv] = c.perm;
    cornerOriDelta[mv] = c.ori;
    const e = C.readEdges(cube);
    edgePerm[mv] = e.perm;
    edgeOriDelta[mv] = e.ori;
  }
  return { cornerPerm, cornerOriDelta, edgePerm, edgeOriDelta };
}

const base = computeBaseTransforms(ALL_MOVES);

// ---- Move-таблицы координат фазы 1 (все 18 ходов) ----

function buildTwistTable() {
  const n = 2187;
  const table = new Uint16Array(n * ALL_MOVES.length);
  for (let idx = 0; idx < n; idx++) {
    const ori = C.indexToOrientation(idx, 3, 8);
    ALL_MOVES.forEach((mv, mi) => {
      const bp = base.cornerPerm[mv], bo = base.cornerOriDelta[mv];
      const newOri = new Array(8);
      for (let s = 0; s < 8; s++) newOri[s] = (ori[bp[s]] + bo[s]) % 3;
      table[idx * ALL_MOVES.length + mi] = C.orientationToIndex(newOri, 3, 8);
    });
  }
  return table;
}

function buildFlipTable() {
  const n = 2048;
  const table = new Uint16Array(n * ALL_MOVES.length);
  for (let idx = 0; idx < n; idx++) {
    const ori = C.indexToOrientation(idx, 2, 12);
    ALL_MOVES.forEach((mv, mi) => {
      const bp = base.edgePerm[mv], bo = base.edgeOriDelta[mv];
      const newOri = new Array(12);
      for (let s = 0; s < 12; s++) newOri[s] = (ori[bp[s]] + bo[s]) % 2;
      table[idx * ALL_MOVES.length + mi] = C.orientationToIndex(newOri, 2, 12);
    });
  }
  return table;
}

function buildUdSliceTable() {
  const n = 495;
  const table = new Uint16Array(n * ALL_MOVES.length);
  for (let idx = 0; idx < n; idx++) {
    const marked = C.indexToCombination(idx, 12, 4);
    ALL_MOVES.forEach((mv, mi) => {
      const bp = base.edgePerm[mv];
      const newMarked = new Array(12);
      for (let s = 0; s < 12; s++) newMarked[s] = marked[bp[s]];
      table[idx * ALL_MOVES.length + mi] = C.combinationToIndex(newMarked, 4);
    });
  }
  return table;
}

// ---- Move-таблицы координат фазы 2 (только 10 ходов подгруппы G1) ----

function buildCornerPermTable() {
  const n = 40320;
  const table = new Uint16Array(n * PHASE2_MOVES.length);
  for (let idx = 0; idx < n; idx++) {
    const perm = C.indexToPermutation(idx, 8);
    PHASE2_MOVES.forEach((mv, mi) => {
      const bp = base.cornerPerm[mv];
      const newPerm = new Array(8);
      for (let s = 0; s < 8; s++) newPerm[s] = perm[bp[s]];
      table[idx * PHASE2_MOVES.length + mi] = C.permutationToIndex(newPerm);
    });
  }
  return table;
}

function buildEdgePerm8Table() {
  const n = 40320;
  const table = new Uint16Array(n * PHASE2_MOVES.length);
  for (let idx = 0; idx < n; idx++) {
    const perm = C.indexToPermutation(idx, 8);
    PHASE2_MOVES.forEach((mv, mi) => {
      const bp = base.edgePerm[mv]; // проверено: для фазы 2 bp[0..7] всегда в 0..7
      const newPerm = new Array(8);
      for (let s = 0; s < 8; s++) newPerm[s] = perm[bp[s]];
      table[idx * PHASE2_MOVES.length + mi] = C.permutationToIndex(newPerm);
    });
  }
  return table;
}

function buildSlicePermTable() {
  const n = 24;
  const table = new Uint16Array(n * PHASE2_MOVES.length);
  for (let idx = 0; idx < n; idx++) {
    const perm = C.indexToPermutation(idx, 4);
    PHASE2_MOVES.forEach((mv, mi) => {
      const bp12 = base.edgePerm[mv];
      const bp4 = [0, 1, 2, 3].map((s) => bp12[8 + s] - C.SLICE_EDGE_START);
      const newPerm = new Array(4);
      for (let s = 0; s < 4; s++) newPerm[s] = perm[bp4[s]];
      table[idx * PHASE2_MOVES.length + mi] = C.permutationToIndex(newPerm);
    });
  }
  return table;
}

// ---- Pruning-таблицы через BFS от собранного состояния ----

function bfsPruning(size, movesCount, applyMoveFn, solvedIndex) {
  const dist = new Uint8Array(size).fill(255);
  dist[solvedIndex] = 0;
  let frontier = new Uint32Array([solvedIndex]);
  let depth = 0;
  let visited = 1;
  while (frontier.length > 0 && visited < size) {
    const nextArr = [];
    for (let fi = 0; fi < frontier.length; fi++) {
      const idx = frontier[fi];
      for (let mi = 0; mi < movesCount; mi++) {
        const nidx = applyMoveFn(idx, mi);
        if (dist[nidx] === 255) {
          dist[nidx] = depth + 1;
          nextArr.push(nidx);
          visited++;
        }
      }
    }
    frontier = Uint32Array.from(nextArr);
    depth++;
  }
  return { dist, maxDepth: depth - 1, visited };
}

// ---- Сериализация ----
function saveTypedArray(name, arr, meta) {
  const buf = Buffer.from(arr.buffer, arr.byteOffset, arr.byteLength);
  const payload = { ...meta, dtype: arr.constructor.name, length: arr.length, data: buf.toString('base64') };
  const filePath = path.join(OUT_DIR, name + '.json');
  fs.writeFileSync(filePath, JSON.stringify(payload));
  const kb = (fs.statSync(filePath).size / 1024).toFixed(1);
  log('saved', name + '.json', `(${kb} KB)`);
}

async function main() {
  const t0 = Date.now();

  log('building phase-1 move tables (twist, flip, udSlice)...');
  const twistTable = buildTwistTable();
  const flipTable = buildFlipTable();
  const udSliceTable = buildUdSliceTable();
  saveTypedArray('twist-move', twistTable, { states: 2187, moves: ALL_MOVES, movesCount: ALL_MOVES.length });
  saveTypedArray('flip-move', flipTable, { states: 2048, moves: ALL_MOVES, movesCount: ALL_MOVES.length });
  saveTypedArray('udslice-move', udSliceTable, { states: 495, moves: ALL_MOVES, movesCount: ALL_MOVES.length });

  log('building phase-2 move tables (cornerPerm, edgePerm8, slicePerm)...');
  const cornerPermTable = buildCornerPermTable();
  const edgePerm8Table = buildEdgePerm8Table();
  const slicePermTable = buildSlicePermTable();
  saveTypedArray('cornerperm-move', cornerPermTable, { states: 40320, moves: PHASE2_MOVES, movesCount: PHASE2_MOVES.length });
  saveTypedArray('edgeperm8-move', edgePerm8Table, { states: 40320, moves: PHASE2_MOVES, movesCount: PHASE2_MOVES.length });
  saveTypedArray('sliceperm-move', slicePermTable, { states: 24, moves: PHASE2_MOVES, movesCount: PHASE2_MOVES.length });

  log('building phase-1 pruning tables via BFS (twist x udSlice, flip x udSlice)...');
  const twistSliceSize = 2187 * 495;
  const twistSliceSolved = 0 * 495 + C.SOLVED_UD_SLICE;
  const { dist: prunTwistSlice, maxDepth: d1, visited: v1 } = bfsPruning(
    twistSliceSize, ALL_MOVES.length,
    (idx, mi) => {
      const twist = Math.floor(idx / 495), slice = idx % 495;
      const nt = twistTable[twist * ALL_MOVES.length + mi];
      const ns = udSliceTable[slice * ALL_MOVES.length + mi];
      return nt * 495 + ns;
    },
    twistSliceSolved,
  );
  log('  twist-slice pruning: maxDepth=', d1, 'visited=', v1, '/', twistSliceSize);

  const flipSliceSize = 2048 * 495;
  const flipSliceSolved = 0 * 495 + C.SOLVED_UD_SLICE;
  const { dist: prunFlipSlice, maxDepth: d2, visited: v2 } = bfsPruning(
    flipSliceSize, ALL_MOVES.length,
    (idx, mi) => {
      const flip = Math.floor(idx / 495), slice = idx % 495;
      const nf = flipTable[flip * ALL_MOVES.length + mi];
      const ns = udSliceTable[slice * ALL_MOVES.length + mi];
      return nf * 495 + ns;
    },
    flipSliceSolved,
  );
  log('  flip-slice pruning: maxDepth=', d2, 'visited=', v2, '/', flipSliceSize);

  saveTypedArray('phase1-prun-twist-slice', prunTwistSlice, { twistStates: 2187, sliceStates: 495, maxDepth: d1 });
  saveTypedArray('phase1-prun-flip-slice', prunFlipSlice, { flipStates: 2048, sliceStates: 495, maxDepth: d2 });

  log('building phase-2 pruning tables via BFS (cornerPerm x slicePerm, edgePerm8 x slicePerm)...');
  const cornerSliceSize = 40320 * 24;
  const { dist: prunCornerSlice, maxDepth: d3, visited: v3 } = bfsPruning(
    cornerSliceSize, PHASE2_MOVES.length,
    (idx, mi) => {
      const corner = Math.floor(idx / 24), slice = idx % 24;
      const nc = cornerPermTable[corner * PHASE2_MOVES.length + mi];
      const ns = slicePermTable[slice * PHASE2_MOVES.length + mi];
      return nc * 24 + ns;
    },
    0,
  );
  log('  corner-slicePerm pruning: maxDepth=', d3, 'visited=', v3, '/', cornerSliceSize);

  const edge8SliceSize = 40320 * 24;
  const { dist: prunEdge8Slice, maxDepth: d4, visited: v4 } = bfsPruning(
    edge8SliceSize, PHASE2_MOVES.length,
    (idx, mi) => {
      const edge8 = Math.floor(idx / 24), slice = idx % 24;
      const ne = edgePerm8Table[edge8 * PHASE2_MOVES.length + mi];
      const ns = slicePermTable[slice * PHASE2_MOVES.length + mi];
      return ne * 24 + ns;
    },
    0,
  );
  log('  edge8-slicePerm pruning: maxDepth=', d4, 'visited=', v4, '/', edge8SliceSize);

  saveTypedArray('phase2-prun-corner-slice', prunCornerSlice, { cornerStates: 40320, sliceStates: 24, maxDepth: d3 });
  saveTypedArray('phase2-prun-edge8-slice', prunEdge8Slice, { edge8States: 40320, sliceStates: 24, maxDepth: d4 });

  // сводный манифест
  fs.writeFileSync(path.join(OUT_DIR, 'manifest.json'), JSON.stringify({
    generatedAt: new Date().toISOString(),
    allMoves: ALL_MOVES,
    phase2Moves: PHASE2_MOVES,
    files: [
      'twist-move.json', 'flip-move.json', 'udslice-move.json',
      'cornerperm-move.json', 'edgeperm8-move.json', 'sliceperm-move.json',
      'phase1-prun-twist-slice.json', 'phase1-prun-flip-slice.json',
      'phase2-prun-corner-slice.json', 'phase2-prun-edge8-slice.json',
    ],
  }, null, 2));

  log('done in', ((Date.now() - t0) / 1000).toFixed(1), 's');
}

main();
