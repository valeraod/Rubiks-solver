// moveOptimizer.js
// Схлопывает соседние ходы по одной грани в один ход (или убирает, если они
// гасят друг друга). Нужно на стыке фазы 1 и фазы 2 и после конкатенации
// решений, где могут оказаться два хода подряд по одной грани.

function faceOf(token) { return token[0]; }
function amountOf(token) {
  // 0 = grip (одна четверть по часовой), 1 = половина, 2 = три четверти (обратный)
  if (token.length === 1) return 1;
  if (token[1] === '2') return 2;
  if (token[1] === "'") return 3;
  throw new Error('moveOptimizer: bad token ' + token);
}
function tokenFromFaceAmount(face, amount) {
  const a = ((amount % 4) + 4) % 4;
  if (a === 0) return null;
  if (a === 1) return face;
  if (a === 2) return face + '2';
  return face + "'";
}

/**
 * @param {string[]} moves
 * @returns {string[]}
 */
export function optimizeMoves(moves) {
  const stack = [];
  for (const mv of moves) {
    if (stack.length > 0 && faceOf(stack[stack.length - 1]) === faceOf(mv)) {
      const combined = amountOf(stack[stack.length - 1]) + amountOf(mv);
      const newToken = tokenFromFaceAmount(faceOf(mv), combined);
      stack.pop();
      if (newToken) stack.push(newToken);
    } else {
      stack.push(mv);
    }
  }
  return stack;
}
