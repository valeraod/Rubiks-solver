// validator.js
// Проверка, что facelets (распознанные с камеры или отредактированные в
// netEditor.js) описывают физически собираемый кубик, прежде чем запускать
// решатель. См. HANDOFF.md §3.6.
//
// Проверки идут по возрастанию "глубины", каждая следующая имеет смысл,
// только если предыдущая прошла — при первой же проблеме возвращаемся с
// понятной причиной вместо мусора дальше по цепочке:
// 1. Структура: все 6 граней по 9 значений, метки — буквы граней
//    (U/R/F/D/L/B), центры совпадают со своей гранью (центры считаются
//    зафиксированными "якорями" цвета — netEditor.js их не даёт менять).
// 2. Счётчики: каждый из 6 цветов встречается ровно 9 раз.
// 3. Физическая собираемость: каждая тройка/пара наклеек одной фигуры
//    (угла/ребра) — реальная комбинация цветов (переиспользуем
//    readCorners/readEdges из kociemba/coordinates.js — та же логика,
//    что и в решателе, а не повторная её реализация); нет двух фигур с
//    одинаковым набором цветов; чётности ориентаций и перестановок сходятся.

import { FACES, cubeFromFacelets } from './engine.js';
import { readCorners, readEdges, CORNER_IDENTITIES, EDGE_IDENTITIES } from './kociemba/coordinates.js';

export const EXPECTED_COUNT = 9;

// Подсчёт вхождений каждой метки по всем 54 наклейкам facelets.
export function countLabels(facelets) {
  const counts = {};
  for (const f of FACES) {
    for (const label of facelets[f] || []) counts[label] = (counts[label] || 0) + 1;
  }
  return counts;
}

// Чётность перестановки (0 — чётная/тождественная, 1 — нечётная) через
// разложение на циклы: чётность = (длина цикла - 1), просуммированная по
// всем циклам, по модулю 2. perm должен быть перестановкой 0..n-1.
export function permutationParity(perm) {
  const seen = new Array(perm.length).fill(false);
  let transpositions = 0;
  for (let i = 0; i < perm.length; i++) {
    if (seen[i]) continue;
    let len = 0;
    let j = i;
    while (!seen[j]) {
      seen[j] = true;
      j = perm[j];
      len++;
    }
    transpositions += Math.max(0, len - 1);
  }
  return transpositions % 2;
}

// Значения, встречающиеся в perm больше одного раза (если perm не является
// настоящей перестановкой — например, две разные фигуры кубика "сошлись"
// на одном и том же наборе цветов, а какой-то другой набор пропал).
export function findDuplicateValues(perm) {
  const seenAt = new Set();
  const dups = new Set();
  for (const v of perm) {
    if (seenAt.has(v)) dups.add(v);
    else seenAt.add(v);
  }
  return [...dups];
}

// Возвращает { valid, errors, cube }. errors — массив { code, message, ... }
// с деталями, полезными UI (face/label/count и т.п.). cube присутствует,
// только если valid === true — уже готовый кубик engine.js для solveCube,
// вызывающему не нужно собирать его повторно.
export function validateFacelets(facelets) {
  const errors = [];

  // 1а. структура: 6 граней по 9 значений
  for (const f of FACES) {
    const arr = facelets[f];
    if (!Array.isArray(arr) || arr.length !== 9) {
      errors.push({
        code: 'BAD_FACE_LENGTH',
        face: f,
        message: `Грань ${f}: должно быть ровно 9 наклеек, получено ${Array.isArray(arr) ? arr.length : 0}.`,
      });
    }
  }
  if (errors.length > 0) return { valid: false, errors };

  // 1б. метки — только известные буквы граней
  for (const f of FACES) {
    for (const label of facelets[f]) {
      if (!FACES.includes(label)) {
        errors.push({
          code: 'UNKNOWN_LABEL',
          face: f,
          label,
          message: `Грань ${f}: неизвестная метка цвета «${label}» (ожидались ${FACES.join('/')}).`,
        });
      }
    }
  }
  if (errors.length > 0) return { valid: false, errors };

  // 1в. центры зафиксированы
  for (const f of FACES) {
    if (facelets[f][4] !== f) {
      errors.push({
        code: 'CENTER_MISMATCH',
        face: f,
        actual: facelets[f][4],
        message: `Центр грани ${f} помечен как «${facelets[f][4]}» — центры не редактируются и должны совпадать со своей гранью.`,
      });
    }
  }
  if (errors.length > 0) return { valid: false, errors };

  // 2. счётчики
  const counts = countLabels(facelets);
  for (const f of FACES) {
    const n = counts[f] || 0;
    if (n !== EXPECTED_COUNT) {
      errors.push({
        code: 'WRONG_COLOR_COUNT',
        label: f,
        count: n,
        message: n > EXPECTED_COUNT
          ? `Цвета «${f}» слишком много: ${n} наклеек вместо 9. Похоже, какая-то наклейка другого цвета распознана или выставлена как «${f}».`
          : `Цвета «${f}» не хватает: ${n} из 9. Похоже, какая-то наклейка «${f}» распознана или выставлена как другой цвет.`,
      });
    }
  }
  if (errors.length > 0) return { valid: false, errors };

  // 3а. физическая собираемость каждой отдельной фигуры
  let cube;
  try {
    cube = cubeFromFacelets(facelets);
  } catch (err) {
    return { valid: false, errors: [{ code: 'BUILD_FAILED', message: 'Не удалось собрать модель кубика: ' + err.message }] };
  }

  let corners;
  let edges;
  try {
    corners = readCorners(cube);
    edges = readEdges(cube);
  } catch {
    return {
      valid: false,
      errors: [{
        code: 'IMPOSSIBLE_PIECE',
        message: 'Кубик несобираем: у одной из фигур (уголка или ребра) невозможное сочетание цветов — например, два одинаковых цвета на одной фигуре, либо цвета противоположных граней рядом. Скорее всего, какая-то наклейка распознана или выставлена неверно — проверьте развёртку.',
      }],
    };
  }

  // 3б. каждая фигура встречается не больше одного раза (perm — настоящая перестановка)
  const dupCorners = findDuplicateValues(corners.perm);
  if (dupCorners.length > 0) {
    const names = dupCorners.map((i) => CORNER_IDENTITIES[i].join('')).join(', ');
    errors.push({ code: 'DUPLICATE_CORNER', identities: dupCorners, message: `Кубик несобираем: набор цветов уголка (${names}) встречается больше одного раза — где-то два уголка перепутаны местами целиком.` });
  }
  const dupEdges = findDuplicateValues(edges.perm);
  if (dupEdges.length > 0) {
    const names = dupEdges.map((i) => EDGE_IDENTITIES[i].join('')).join(', ');
    errors.push({ code: 'DUPLICATE_EDGE', identities: dupEdges, message: `Кубик несобираем: набор цветов ребра (${names}) встречается больше одного раза — где-то два ребра перепутаны местами целиком.` });
  }
  if (errors.length > 0) return { valid: false, errors };

  // 3в. чётности (см. HANDOFF §3.6, пункт 3)
  const twistSum = corners.ori.reduce((a, b) => a + b, 0) % 3;
  if (twistSum !== 0) {
    errors.push({ code: 'CORNER_TWIST_PARITY', message: 'Кубик несобираем: суммарная ориентация уголков не кратна 3 — один из уголков "повёрнут вокруг своей оси" неверно. Обычно это ошибка на одной угловой наклейке.' });
  }
  const flipSum = edges.ori.reduce((a, b) => a + b, 0) % 2;
  if (flipSum !== 0) {
    errors.push({ code: 'EDGE_FLIP_PARITY', message: 'Кубик несобираем: суммарная ориентация рёбер не кратна 2 — одно из рёбер "перевёрнуто" неверно. Обычно это ошибка на одной реберной наклейке.' });
  }
  const cornerParity = permutationParity(corners.perm);
  const edgeParity = permutationParity(edges.perm);
  if (cornerParity !== edgeParity) {
    errors.push({ code: 'PERMUTATION_PARITY', message: 'Кубик несобираем: чётность перестановки уголков не совпадает с чётностью перестановки рёбер — похоже, где-то целиком переставлены местами (обменяны) две наклейки, а не повёрнуты.' });
  }

  if (errors.length > 0) return { valid: false, errors };
  return { valid: true, errors: [], cube };
}

export function isSolvable(facelets) {
  return validateFacelets(facelets).valid;
}
