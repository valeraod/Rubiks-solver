import test from 'node:test';
import assert from 'node:assert/strict';
import path from 'path';
import { fileURLToPath } from 'url';
import * as E from '../js/engine.js';
import { loadTables, nodeFetchJson } from '../js/kociemba/tables.js';
import { solveCube } from '../js/kociemba/solve.js';
import { detectCubeColors } from '../js/colorDetect.js';
import {
  CAPTURE_STEPS, defaultGridRect, isGridRectValid, extractGridImageData, CaptureWizard,
} from '../js/capture.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const TABLES_DIR = path.join(__dirname, '..', 'data', 'tables');

let tables;
test.before(async () => {
  tables = await loadTables(nodeFetchJson(TABLES_DIR));
});

const STICKER_RGB = {
  U: { r: 255, g: 255, b: 255 },
  R: { r: 196, g: 30, b: 40 },
  F: { r: 0, g: 140, b: 70 },
  D: { r: 255, g: 213, b: 0 },
  L: { r: 255, g: 110, b: 20 },
  B: { r: 20, g: 70, b: 180 },
};

// Строит "сырой кадр" size x size с фоном bgColor и с квадратом 3x3
// заданных цветов внутри gridRect — имитация фото, где сама наклейка-сетка
// занимает не весь кадр (как в реальной съёмке с рук).
function makeRawFrame(width, height, gridRect, colors, bgColor = { r: 40, g: 40, b: 40 }) {
  const data = new Uint8ClampedArray(width * height * 4);
  for (let y = 0; y < height; y++) {
    for (let x = 0; x < width; x++) {
      const i = (y * width + x) * 4;
      let color = bgColor;
      if (x >= gridRect.x && x < gridRect.x + gridRect.size && y >= gridRect.y && y < gridRect.y + gridRect.size) {
        const cellSize = gridRect.size / 3;
        const c = Math.min(2, Math.floor((x - gridRect.x) / cellSize));
        const r = Math.min(2, Math.floor((y - gridRect.y) / cellSize));
        color = colors[r * 3 + c];
      }
      data[i] = color.r; data[i + 1] = color.g; data[i + 2] = color.b; data[i + 3] = 255;
    }
  }
  return { width, height, data };
}

test('CAPTURE_STEPS: 6 шагов, ровно по одному на каждую грань движка, в фиксированном порядке протокола', () => {
  assert.equal(CAPTURE_STEPS.length, 6);
  assert.deepEqual(CAPTURE_STEPS.map((s) => s.face).sort(), [...E.FACES].sort());
  assert.deepEqual(CAPTURE_STEPS.map((s) => s.face), ['F', 'U', 'B', 'D', 'R', 'L']);
  for (const s of CAPTURE_STEPS) {
    assert.equal(typeof s.title, 'string');
    assert.equal(typeof s.instruction, 'string');
    assert.ok(s.title.length > 0 && s.instruction.length > 0);
  }
});

test('CAPTURE_STEPS: смена хвата отмечена ровно один раз, перед гранью R', () => {
  const regripSteps = CAPTURE_STEPS.filter((s) => s.regrip);
  assert.equal(regripSteps.length, 1);
  assert.equal(regripSteps[0].face, 'R');
});

test('defaultGridRect: квадрат по центру, 60% меньшей стороны', () => {
  const rect = defaultGridRect(400, 200);
  assert.equal(rect.size, Math.round(200 * 0.6));
  assert.equal(rect.x, Math.round((400 - rect.size) / 2));
  assert.equal(rect.y, Math.round((200 - rect.size) / 2));
  assert.ok(isGridRectValid(400, 200, rect));
});

test('isGridRectValid: отвергает выход за границы и нулевой/отрицательный размер', () => {
  assert.equal(isGridRectValid(100, 100, { x: 0, y: 0, size: 100 }), true);
  assert.equal(isGridRectValid(100, 100, { x: 1, y: 0, size: 100 }), false, 'выходит за правую границу');
  assert.equal(isGridRectValid(100, 100, { x: 0, y: -1, size: 50 }), false, 'отрицательный y');
  assert.equal(isGridRectValid(100, 100, { x: 0, y: 0, size: 0 }), false, 'нулевой размер');
  assert.equal(isGridRectValid(100, 100, { x: 0, y: 0, size: -10 }), false, 'отрицательный размер');
});

test('extractGridImageData: вырезает ровно заданный квадрат с точными пикселями', () => {
  const rect = { x: 10, y: 20, size: 9 };
  const colors = [
    STICKER_RGB.U, STICKER_RGB.R, STICKER_RGB.F,
    STICKER_RGB.D, STICKER_RGB.L, STICKER_RGB.B,
    STICKER_RGB.U, STICKER_RGB.R, STICKER_RGB.F,
  ];
  const frame = makeRawFrame(100, 80, rect, colors);
  const cropped = extractGridImageData(frame, rect);
  assert.equal(cropped.width, 9);
  assert.equal(cropped.height, 9);
  // проверяем угловой и центральный пиксель вырезки против исходной сетки
  const cell = 3; // 9/3
  const checkCell = (r, c) => {
    const px = (r * cell + 1) * cropped.width + (c * cell + 1);
    const i = px * 4;
    assert.equal(cropped.data[i], colors[r * 3 + c].r, `r${r}c${c} R`);
    assert.equal(cropped.data[i + 1], colors[r * 3 + c].g, `r${r}c${c} G`);
    assert.equal(cropped.data[i + 2], colors[r * 3 + c].b, `r${r}c${c} B`);
  };
  for (let r = 0; r < 3; r++) for (let c = 0; c < 3; c++) checkCell(r, c);
});

test('extractGridImageData: бросает ошибку, если сетка выходит за границы кадра', () => {
  const frame = makeRawFrame(50, 50, { x: 0, y: 0, size: 50 }, new Array(9).fill(STICKER_RGB.U));
  assert.throws(() => extractGridImageData(frame, { x: 10, y: 10, size: 50 }), /выходит за границы/);
});

test('CaptureWizard: начальное состояние — первый шаг (F), ничего не снято', () => {
  const w = new CaptureWizard();
  assert.equal(w.stepIndex, 0);
  assert.equal(w.step.face, 'F');
  assert.deepEqual(w.progress, { current: 1, total: 6 });
  assert.equal(w.hasCurrent(), false);
  assert.equal(w.isComplete(), false);
});

test('CaptureWizard: next() требует снятого кадра, back() не уходит раньше первого шага', () => {
  const w = new CaptureWizard();
  assert.throws(() => w.next(), /текущий кадр ещё не снят/);
  assert.throws(() => w.back(), /уже на первом кадре/);
});

test('CaptureWizard: captureCurrent -> next по всем 6 шагам, retake, goToStep', () => {
  const w = new CaptureWizard();
  const rect = defaultGridRect(60, 60);
  for (let i = 0; i < 6; i++) {
    assert.equal(w.hasCurrent(), false);
    const frame = makeRawFrame(60, 60, rect, new Array(9).fill(STICKER_RGB[w.step.face]));
    w.captureCurrent(frame, rect);
    assert.equal(w.hasCurrent(), true);
    if (!w.isLastStep) w.next(); else break;
  }
  assert.equal(w.isComplete(), true);

  // переснять грань L (текущий последний шаг) и убедиться, что после retake кадра нет
  w.retakeCurrent();
  assert.equal(w.hasCurrent(), false);
  assert.equal(w.isComplete(), false);

  // прыжок на первый шаг и обратно
  w.goToStep(0);
  assert.equal(w.step.face, 'F');
  assert.equal(w.hasCurrent(), true); // F был снят на первой итерации цикла выше
  w.goToStep(5);
  assert.equal(w.step.face, 'L');

  assert.throws(() => w.goToStep(6), /вне диапазона/);
  assert.throws(() => w.goToStep(-1), /вне диапазона/);
});

test('CaptureWizard: finish() бросает ошибку и перечисляет недостающие грани, если снято не всё', () => {
  const w = new CaptureWizard();
  const rect = defaultGridRect(60, 60);
  const frame = makeRawFrame(60, 60, rect, new Array(9).fill(STICKER_RGB.F));
  w.captureCurrent(frame, rect);
  assert.throws(() => w.finish(), /не хватает: U, B, D, R, L/);
});

test('CaptureWizard: полный проход всех 6 шагов, finish() отдаёт объект по буквам граней движка', () => {
  const w = new CaptureWizard();
  const rect = defaultGridRect(90, 90);
  while (true) {
    const frame = makeRawFrame(90, 90, rect, new Array(9).fill(STICKER_RGB[w.step.face]));
    w.captureCurrent(frame, rect);
    if (w.isLastStep) break;
    w.next();
  }
  const facesImages = w.finish();
  assert.deepEqual(Object.keys(facesImages).sort(), [...E.FACES].sort());
  for (const f of E.FACES) {
    assert.equal(facesImages[f].width, rect.size);
    assert.equal(facesImages[f].height, rect.size);
  }
});

test('сквозной сценарий: CaptureWizard -> colorDetect -> engine -> solveCube на случайно перемешанном кубике', () => {
  const cube = E.newSolvedCube();
  const MOVESET = [];
  for (const f of ['U', 'D', 'L', 'R', 'F', 'B']) for (const m of ['', "'", '2']) MOVESET.push(f + m);
  const scramble = [];
  for (let i = 0; i < 20; i++) scramble.push(MOVESET[Math.floor(Math.random() * MOVESET.length)]);
  E.applyMoves(cube, scramble);
  const expectedFacelets = E.getAllFacelets(cube);

  const w = new CaptureWizard();
  // на каждом шаге — кадр со сдвинутой/несовпадающей с дефолтной сеткой,
  // как будто пользователь каждый раз немного иначе наводит рамку
  while (true) {
    const face = w.step.face;
    const frameSize = 200 + Math.floor(Math.random() * 40);
    const rect = { x: 15, y: 25, size: 150 };
    const frame = makeRawFrame(frameSize, frameSize, rect, expectedFacelets[face].map((l) => STICKER_RGB[l]));
    w.captureCurrent(frame, rect);
    if (w.isLastStep) break;
    w.next();
  }
  const facesImages = w.finish();

  const { facelets: detected } = detectCubeColors(facesImages);
  for (const f of E.FACES) assert.deepEqual(detected[f], expectedFacelets[f], `грань ${f}`);

  const rebuilt = E.cubeFromFacelets(detected);
  const result = solveCube(rebuilt, tables);
  assert.equal(result.solved, true);
});
