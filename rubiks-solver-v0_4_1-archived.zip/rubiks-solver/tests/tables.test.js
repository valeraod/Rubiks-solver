import test from 'node:test';
import assert from 'node:assert/strict';
import path from 'path';
import { fileURLToPath } from 'url';
import * as E from '../js/engine.js';
import * as C from '../js/kociemba/coordinates.js';
import { loadTables, nodeFetchJson } from '../js/kociemba/tables.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const TABLES_DIR = path.join(__dirname, '..', 'data', 'tables');

let tables;
test.before(async () => {
  tables = await loadTables(nodeFetchJson(TABLES_DIR));
});

test('move tables match ground-truth engine.js simulation for random scrambles (phase 1 coords)', () => {
  const { allMoves } = tables.meta;
  for (let t = 0; t < 30; t++) {
    const cube = E.newSolvedCube();
    let twist = 0, flip = 0, udSlice = C.SOLVED_UD_SLICE;
    const seq = [];
    for (let i = 0; i < 15; i++) {
      const mi = Math.floor(Math.random() * allMoves.length);
      const mv = allMoves[mi];
      seq.push(mv);
      E.applyMove(cube, mv);
      twist = tables.twistMove[twist * allMoves.length + mi];
      flip = tables.flipMove[flip * allMoves.length + mi];
      udSlice = tables.udSliceMove[udSlice * allMoves.length + mi];
    }
    const ground = C.computeAllCoordinates(cube);
    assert.equal(twist, ground.twist, 'twist mismatch, seq: ' + seq.join(' '));
    assert.equal(flip, ground.flip, 'flip mismatch, seq: ' + seq.join(' '));
    assert.equal(udSlice, ground.udSlice, 'udSlice mismatch, seq: ' + seq.join(' '));
  }
});

test('move tables match ground-truth engine.js simulation for random phase-2-only scrambles', () => {
  const { phase2Moves } = tables.meta;
  for (let t = 0; t < 30; t++) {
    const cube = E.newSolvedCube();
    let cornerPerm = 0, edgePerm8 = 0, slicePerm = 0;
    const seq = [];
    for (let i = 0; i < 15; i++) {
      const mi = Math.floor(Math.random() * phase2Moves.length);
      const mv = phase2Moves[mi];
      seq.push(mv);
      E.applyMove(cube, mv);
      cornerPerm = tables.cornerPermMove[cornerPerm * phase2Moves.length + mi];
      edgePerm8 = tables.edgePerm8Move[edgePerm8 * phase2Moves.length + mi];
      slicePerm = tables.slicePermMove[slicePerm * phase2Moves.length + mi];
    }
    const ground = C.computeAllCoordinates(cube);
    assert.equal(cornerPerm, ground.cornerPerm, 'cornerPerm mismatch, seq: ' + seq.join(' '));
    assert.equal(edgePerm8, ground.edgePerm8, 'edgePerm8 mismatch, seq: ' + seq.join(' '));
    assert.equal(slicePerm, ground.slicePerm, 'slicePerm mismatch, seq: ' + seq.join(' '));
    // phase-2-only moves must keep the cube within G1 (already implied by earlier
    // coordinates.test.js check, re-verified here for the same random sequences)
    assert.equal(ground.twist, 0);
    assert.equal(ground.flip, 0);
    assert.equal(ground.udSlice, C.SOLVED_UD_SLICE);
  }
});

test('pruning tables: solved state has distance 0, and are fully reachable (no unreached entries)', () => {
  assert.equal(tables.prunTwistSlice[0 * 495 + C.SOLVED_UD_SLICE], 0);
  assert.equal(tables.prunFlipSlice[0 * 495 + C.SOLVED_UD_SLICE], 0);
  assert.equal(tables.prunCornerSlice[0 * 24 + 0], 0);
  assert.equal(tables.prunEdge8Slice[0 * 24 + 0], 0);

  for (const [name, arr] of Object.entries({
    prunTwistSlice: tables.prunTwistSlice,
    prunFlipSlice: tables.prunFlipSlice,
    prunCornerSlice: tables.prunCornerSlice,
    prunEdge8Slice: tables.prunEdge8Slice,
  })) {
    let unreached = 0;
    for (let i = 0; i < arr.length; i++) if (arr[i] === 255) unreached++;
    assert.equal(unreached, 0, name + ' has ' + unreached + ' unreached entries');
  }
});

test('pruning table distance never increases by more than 1 across a single move (admissible-heuristic sanity check)', () => {
  const { allMoves } = tables.meta;
  for (let trial = 0; trial < 500; trial++) {
    const twist = Math.floor(Math.random() * 2187);
    const slice = Math.floor(Math.random() * 495);
    const d0 = tables.prunTwistSlice[twist * 495 + slice];
    const mi = Math.floor(Math.random() * allMoves.length);
    const nt = tables.twistMove[twist * allMoves.length + mi];
    const ns = tables.udSliceMove[slice * allMoves.length + mi];
    const d1 = tables.prunTwistSlice[nt * 495 + ns];
    assert.ok(Math.abs(d1 - d0) <= 1, `distance jumped by more than 1: ${d0} -> ${d1}`);
  }
});
