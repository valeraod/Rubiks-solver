// captureDemo.js
// Тонкая браузерная обвязка index.html поверх capture.js + colorDetect.js —
// рабочий стенд для ручной проверки этапа 0.3.0 (см. HANDOFF.md §3.3/3.4).
// Логика мастера и обработка кадров headless-тестируются в capture.js и
// colorDetect.js; этот файл — только DOM-склейка и не содержит бизнес-логики.
//
// Временный: в 0.5.0 функциональность съёмки войдёт в main.js вместе с
// редактором/валидатором/плеером решения; этот файл будет заменён.

import {
  CAPTURE_STEPS, CaptureWizard, defaultGridRect,
  startCamera, stopCamera, grabFrameFromVideo, loadImageFile,
} from './capture.js';
import { detectCubeColors } from './colorDetect.js';
import { NetEditor, rotateGridTimes } from './netEditor.js';
import { FACES } from './engine.js';

const el = (id) => document.getElementById(id);

const dom = {
  steps: el('steps'),
  stepTitle: el('stepTitle'),
  stepInstruction: el('stepInstruction'),
  stepWarn: el('stepWarn'),
  stage: el('stage'),
  video: el('video'),
  stillCanvas: el('stillCanvas'),
  cameraViewfinder: el('cameraViewfinder'),
  fileGrid: el('fileGrid'),
  stageEmpty: el('stageEmpty'),
  stageError: el('stageError'),
  modeCameraBtn: el('modeCameraBtn'),
  modeFileBtn: el('modeFileBtn'),
  fileInput: el('fileInput'),
  gridSizeWrap: el('gridSizeWrap'),
  gridSizeSlider: el('gridSizeSlider'),
  backBtn: el('backBtn'),
  retakeBtn: el('retakeBtn'),
  captureBtn: el('captureBtn'),
  nextBtn: el('nextBtn'),
  finishBtn: el('finishBtn'),
  result: el('result'),
  resultNet: el('resultNet'),
  resultCounts: el('resultCounts'),
  resultValidation: el('resultValidation'),
};

const wizard = new CaptureWizard();

let mode = null; // 'camera' | 'file'
let cameraStream = null;
let fileImageData = null; // ImageData текущего загруженного файла (для текущего шага)
let fileGridRect = null; // { x, y, size } в пиксельных координатах fileImageData

// ---- индикатор шагов ----

for (const [i, step] of CAPTURE_STEPS.entries()) {
  const li = document.createElement('li');
  const btn = document.createElement('button');
  btn.type = 'button';
  btn.className = 'steps__dot';
  btn.style.setProperty('--dot-color', `var(--sticker-${step.face})`);
  btn.setAttribute('aria-label', step.title);
  btn.addEventListener('click', () => {
    wizard.goToStep(i);
    onStepChanged();
  });
  li.appendChild(btn);
  dom.steps.appendChild(li);
}

function renderStep() {
  const step = wizard.step;
  dom.stepTitle.textContent = step.title;
  dom.stepInstruction.textContent = step.instruction;
  if (step.warn) {
    dom.stepWarn.textContent = step.warn;
    dom.stepWarn.hidden = false;
  } else {
    dom.stepWarn.hidden = true;
  }

  [...dom.steps.children].forEach((li, i) => {
    const btn = li.firstChild;
    btn.dataset.current = String(i === wizard.stepIndex);
    btn.dataset.done = String(!!wizard.captured[CAPTURE_STEPS[i].face]);
  });

  const has = wizard.hasCurrent();
  dom.backBtn.disabled = wizard.stepIndex === 0;
  dom.retakeBtn.hidden = !has;
  dom.captureBtn.hidden = has;
  dom.captureBtn.disabled = mode === null || (mode === 'file' && !fileImageData);
  dom.nextBtn.hidden = !(has && !wizard.isLastStep);
  dom.finishBtn.hidden = !(has && wizard.isLastStep);
}

function onStepChanged() {
  dom.result.hidden = true;
  if (mode === 'file') resetFileFrame();
  renderStep();
}

// ---- источник кадра: камера ----

async function setModeCamera() {
  stopFileFrame();
  hideError();
  mode = 'camera';
  dom.modeCameraBtn.setAttribute('aria-pressed', 'true');
  dom.modeFileBtn.setAttribute('aria-pressed', 'false');
  dom.gridSizeWrap.hidden = true;
  dom.fileGrid.hidden = true;
  dom.stage.dataset.mode = 'camera';
  dom.captureBtn.disabled = true;
  try {
    cameraStream = await startCamera(dom.video);
    dom.cameraViewfinder.hidden = false;
    dom.stageEmpty.hidden = true;
    renderStep();
  } catch (err) {
    dom.cameraViewfinder.hidden = true;
    dom.stage.dataset.mode = 'none';
    showError('Не удалось включить камеру (' + err.message + '). Можно загрузить фото вместо этого — кнопка «Файл».');
  }
}

function stopCameraIfRunning() {
  if (cameraStream) {
    stopCamera(cameraStream);
    cameraStream = null;
  }
  dom.cameraViewfinder.hidden = true;
}

// ---- источник кадра: файл ----

function setModeFile() {
  stopCameraIfRunning();
  hideError();
  mode = 'file';
  dom.modeCameraBtn.setAttribute('aria-pressed', 'false');
  dom.modeFileBtn.setAttribute('aria-pressed', 'true');
  dom.stage.dataset.mode = 'file';
  dom.gridSizeWrap.hidden = false;
  resetFileFrame();
  dom.fileInput.click();
}

function resetFileFrame() {
  fileImageData = null;
  fileGridRect = null;
  dom.fileGrid.hidden = true;
  dom.stillCanvas.getContext('2d')?.clearRect(0, 0, dom.stillCanvas.width, dom.stillCanvas.height);
  if (mode === 'file') {
    dom.stageEmpty.hidden = false;
    dom.stageEmpty.textContent = 'Загрузите фото этой грани';
  }
}

function stopFileFrame() {
  fileImageData = null;
  fileGridRect = null;
  dom.fileGrid.hidden = true;
}

dom.fileInput.addEventListener('change', async () => {
  const file = dom.fileInput.files?.[0];
  dom.fileInput.value = '';
  if (!file) return;
  try {
    fileImageData = await loadImageFile(file);
  } catch (err) {
    showError('Не удалось прочитать файл (' + err.message + ').');
    return;
  }
  dom.stillCanvas.width = fileImageData.width;
  dom.stillCanvas.height = fileImageData.height;
  dom.stillCanvas.getContext('2d').putImageData(fileImageData, 0, 0);
  dom.stageEmpty.hidden = true;
  hideError();

  const pct = Number(dom.gridSizeSlider.value) / 100;
  const minSide = Math.min(fileImageData.width, fileImageData.height);
  const size = Math.round(minSide * pct);
  fileGridRect = {
    x: Math.round((fileImageData.width - size) / 2),
    y: Math.round((fileImageData.height - size) / 2),
    size,
  };
  dom.fileGrid.hidden = false;
  positionFileGrid();
  renderStep();
});

dom.gridSizeSlider.addEventListener('input', () => {
  if (!fileImageData) return;
  const pct = Number(dom.gridSizeSlider.value) / 100;
  const minSide = Math.min(fileImageData.width, fileImageData.height);
  const size = Math.max(10, Math.round(minSide * pct));
  const cx = fileGridRect.x + fileGridRect.size / 2;
  const cy = fileGridRect.y + fileGridRect.size / 2;
  fileGridRect = clampRect({ x: cx - size / 2, y: cy - size / 2, size }, fileImageData.width, fileImageData.height);
  positionFileGrid();
});

function clampRect(rect, width, height) {
  const size = Math.min(rect.size, width, height);
  const x = Math.min(Math.max(0, rect.x), width - size);
  const y = Math.min(Math.max(0, rect.y), height - size);
  return { x: Math.round(x), y: Math.round(y), size: Math.round(size) };
}

// object-fit: contain — вычисляем реальный прямоугольник картинки на экране
// относительно .stage, чтобы верно сопоставлять курсор <-> пиксели файла.
function containRectOnScreen() {
  const stageBox = dom.stage.getBoundingClientRect();
  const canvasBox = dom.stillCanvas.getBoundingClientRect();
  const scale = Math.min(canvasBox.width / dom.stillCanvas.width, canvasBox.height / dom.stillCanvas.height);
  const dispW = dom.stillCanvas.width * scale;
  const dispH = dom.stillCanvas.height * scale;
  const left = (canvasBox.left - stageBox.left) + (canvasBox.width - dispW) / 2;
  const top = (canvasBox.top - stageBox.top) + (canvasBox.height - dispH) / 2;
  return { left, top, scale };
}

function positionFileGrid() {
  if (!fileGridRect) return;
  const { left, top, scale } = containRectOnScreen();
  dom.fileGrid.style.left = `${left + fileGridRect.x * scale}px`;
  dom.fileGrid.style.top = `${top + fileGridRect.y * scale}px`;
  dom.fileGrid.style.width = `${fileGridRect.size * scale}px`;
  dom.fileGrid.style.height = `${fileGridRect.size * scale}px`;
}

let dragStart = null;
dom.fileGrid.addEventListener('pointerdown', (e) => {
  if (!fileGridRect) return;
  dom.fileGrid.setPointerCapture(e.pointerId);
  dragStart = { px: e.clientX, py: e.clientY, rect: { ...fileGridRect } };
});
dom.fileGrid.addEventListener('pointermove', (e) => {
  if (!dragStart || !fileImageData) return;
  const { scale } = containRectOnScreen();
  const dx = (e.clientX - dragStart.px) / scale;
  const dy = (e.clientY - dragStart.py) / scale;
  fileGridRect = clampRect(
    { x: dragStart.rect.x + dx, y: dragStart.rect.y + dy, size: dragStart.rect.size },
    fileImageData.width, fileImageData.height,
  );
  positionFileGrid();
});
dom.fileGrid.addEventListener('pointerup', () => { dragStart = null; });
dom.fileGrid.addEventListener('pointercancel', () => { dragStart = null; });

window.addEventListener('resize', () => { if (mode === 'file') positionFileGrid(); });

// ---- ошибки/пустое состояние ----

function showError(msg) {
  dom.stageError.textContent = msg;
  dom.stageError.hidden = false;
}
function hideError() {
  dom.stageError.hidden = true;
}

// ---- кнопки мастера ----

dom.modeCameraBtn.addEventListener('click', setModeCamera);
dom.modeFileBtn.addEventListener('click', setModeFile);

dom.captureBtn.addEventListener('click', () => {
  try {
    if (mode === 'camera') {
      const frame = grabFrameFromVideo(dom.video);
      wizard.captureCurrent(frame, defaultGridRect(frame.width, frame.height));
    } else if (mode === 'file') {
      if (!fileImageData) return;
      wizard.captureCurrent(fileImageData, fileGridRect);
    } else {
      return;
    }
    hideError();
    renderStep();
  } catch (err) {
    showError('Не удалось снять кадр (' + err.message + ').');
  }
});

dom.retakeBtn.addEventListener('click', () => {
  wizard.retakeCurrent();
  if (mode === 'file') resetFileFrame();
  dom.result.hidden = true;
  renderStep();
});

dom.backBtn.addEventListener('click', () => { wizard.back(); onStepChanged(); });
dom.nextBtn.addEventListener('click', () => { wizard.next(); onStepChanged(); });

let editor = null; // NetEditor текущего результата (создаётся после finish())
let lowConfidence = null; // { U:[9 bool], ... } — исходная подсказка от colorDetect, гаснет по мере правок

dom.finishBtn.addEventListener('click', () => {
  try {
    const facesImages = wizard.finish();
    const { facelets, confidence } = detectCubeColors(facesImages);
    editor = new NetEditor(facelets);
    lowConfidence = {};
    for (const f of FACES) lowConfidence[f] = confidence[f].map((c) => c < 0.5);
    renderResult();
  } catch (err) {
    showError('Не удалось распознать кубик (' + err.message + ').');
  }
});

// ---- результат: редактируемая развёртка кубика (netEditor.js) ----

const netCells = {}; // f -> [button x9]

for (const f of FACES) {
  const faceEl = document.createElement('div');
  faceEl.className = 'net__face';
  faceEl.dataset.face = f;

  const rotateBtn = document.createElement('button');
  rotateBtn.type = 'button';
  rotateBtn.className = 'net__rotate';
  rotateBtn.title = `Повернуть грань ${f}`;
  rotateBtn.textContent = '↻';
  rotateBtn.addEventListener('click', () => {
    if (!editor) return;
    editor.rotateFace(f, 1);
    if (lowConfidence) lowConfidence[f] = rotateGridTimes(lowConfidence[f], 1);
    renderResult();
  });
  faceEl.appendChild(rotateBtn);

  const gridEl = document.createElement('div');
  gridEl.className = 'net__grid';
  const cells = [];
  for (let i = 0; i < 9; i++) {
    const cell = document.createElement('button');
    cell.type = 'button';
    cell.className = 'net__cell';
    if (i === 4) {
      cell.disabled = true; // центр не редактируется (см. validator.js: CENTER_MISMATCH)
    } else {
      cell.addEventListener('click', (e) => {
        if (!editor) return;
        editor.cycleSticker(f, i, e.shiftKey ? -1 : 1);
        if (lowConfidence) lowConfidence[f][i] = false; // клетку поправили руками — подсказка больше не нужна
        renderResult();
      });
    }
    gridEl.appendChild(cell);
    cells.push(cell);
  }
  faceEl.appendChild(gridEl);
  netCells[f] = cells;
  dom.resultNet.appendChild(faceEl);
}

function renderResult() {
  const { facelets, counts, validation } = editor;
  for (const f of FACES) {
    for (let i = 0; i < 9; i++) {
      const label = facelets[f][i];
      netCells[f][i].style.setProperty('--sticker-color', `var(--sticker-${label})`);
      netCells[f][i].dataset.lowConfidence = String(!!(lowConfidence && lowConfidence[f][i]));
    }
  }

  dom.resultCounts.innerHTML = '';
  for (const f of FACES) {
    const n = counts[f] || 0;
    const badge = document.createElement('span');
    badge.className = 'counts__badge';
    badge.dataset.ok = String(n === 9);
    badge.innerHTML = `<span class="counts__swatch" style="--sticker-color:var(--sticker-${f})"></span>${n}/9`;
    dom.resultCounts.appendChild(badge);
  }

  dom.resultValidation.dataset.ok = String(validation.valid);
  if (validation.valid) {
    dom.resultValidation.textContent = 'Кубик собираем — можно передавать в решатель (в 0.5.0).';
  } else {
    const ul = document.createElement('ul');
    for (const err of validation.errors) {
      const li = document.createElement('li');
      li.textContent = err.message;
      ul.appendChild(li);
    }
    dom.resultValidation.innerHTML = '';
    dom.resultValidation.appendChild(ul);
  }

  dom.result.hidden = false;
}

// ---- старт ----

renderStep();
