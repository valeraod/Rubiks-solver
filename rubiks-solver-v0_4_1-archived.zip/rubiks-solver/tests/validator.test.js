import test from 'node:test';
import assert from 'node:assert/strict';
import * as E from '../js/engine.js';
import {
  validateFacelets, isSolvable, countLabels, permutationParity, findDuplicateValues, EXPECTED_COUNT,
} from '../js/validator.js';

function solvedFacelets() {
  return E.getAllFacelets(E.newSolvedCube());
}

function scrambledFacelets(moves) {
  const cube = E.newSolvedCube();
  E.applyMoves(cube, moves);
  return E.getAllFacelets(cube);
}

test('countLabels: на собранном кубике ровно по 9 каждого цвета', () => {
  const counts = countLabels(solvedFacelets());
  for (const f of E.FACES) assert.equal(counts[f], EXPECTED_COUNT);
});

test('permutationParity: тождественная перестановка чётная, одна транспозиция — нечётная', () => {
  assert.equal(permutationParity([0, 1, 2, 3]), 0);
  assert.equal(permutationParity([1, 0, 2, 3]), 1);
  assert.equal(permutationParity([1, 2, 0]), 0); // 3-цикл = 2 транспозиции, чётная
  assert.equal(permutationParity([1, 0, 3, 2]), 0); // две независимые транспозиции
});

test('findDuplicateValues: находит значения, встречающиеся больше одного раза', () => {
  assert.deepEqual(findDuplicateValues([0, 1, 2, 3]), []);
  assert.deepEqual(findDuplicateValues([0, 1, 0, 3]), [0]);
  const dups = findDuplicateValues([0, 1, 0, 3, 1]);
  assert.deepEqual([...dups].sort(), [0, 1]);
});

test('validateFacelets: собранный кубик — валиден, отдаёт готовый cube', () => {
  const result = validateFacelets(solvedFacelets());
  assert.equal(result.valid, true);
  assert.deepEqual(result.errors, []);
  assert.ok(Array.isArray(result.cube));
  assert.equal(E.isSolved(result.cube), true);
});

test('validateFacelets: случайно перемешанный (легитимными ходами) кубик — валиден', () => {
  const MOVESET = [];
  for (const f of ['U', 'D', 'L', 'R', 'F', 'B']) for (const m of ['', "'", '2']) MOVESET.push(f + m);
  const scramble = [];
  for (let i = 0; i < 20; i++) scramble.push(MOVESET[Math.floor(Math.random() * MOVESET.length)]);
  const result = validateFacelets(scrambledFacelets(scramble));
  assert.equal(result.valid, true, JSON.stringify(result.errors));
});

test('isSolvable: тонкая обёртка над validateFacelets().valid', () => {
  assert.equal(isSolvable(solvedFacelets()), true);
  const bad = solvedFacelets();
  bad.U[0] = 'R'; bad.R[0] = 'U';
  assert.equal(isSolvable(bad), false);
});

test('validateFacelets: BAD_FACE_LENGTH при неверном числе наклеек на грани', () => {
  const f = solvedFacelets();
  f.U = f.U.slice(0, 8);
  const result = validateFacelets(f);
  assert.equal(result.valid, false);
  assert.equal(result.errors[0].code, 'BAD_FACE_LENGTH');
  assert.equal(result.errors[0].face, 'U');
});

test('validateFacelets: UNKNOWN_LABEL при метке вне набора граней', () => {
  const f = solvedFacelets();
  f.U[0] = 'X';
  const result = validateFacelets(f);
  assert.equal(result.valid, false);
  assert.equal(result.errors[0].code, 'UNKNOWN_LABEL');
  assert.equal(result.errors[0].label, 'X');
});

test('validateFacelets: CENTER_MISMATCH при смещённом/перепутанном центре', () => {
  const f = solvedFacelets();
  f.U[4] = 'R';
  const result = validateFacelets(f);
  assert.equal(result.valid, false);
  assert.equal(result.errors[0].code, 'CENTER_MISMATCH');
  assert.equal(result.errors[0].face, 'U');
});

test('validateFacelets: WRONG_COLOR_COUNT при неверном числе наклеек одного цвета', () => {
  const f = solvedFacelets();
  f.U[0] = 'R'; // U теперь 8 раз, R — 10 раз, но центры/структура/метки в порядке
  const result = validateFacelets(f);
  assert.equal(result.valid, false);
  const codes = result.errors.map((e) => e.code);
  assert.ok(codes.every((c) => c === 'WRONG_COLOR_COUNT'));
  const byLabel = Object.fromEntries(result.errors.map((e) => [e.label, e.count]));
  assert.equal(byLabel.U, 8);
  assert.equal(byLabel.R, 10);
});

test('validateFacelets: IMPOSSIBLE_PIECE при физически невозможном сочетании цветов фигуры', () => {
  // Наклейки U[0] и R[0] принадлежат разным физическим уголкам (ULB и URF);
  // обмен их метками даёт уголку ULB набор цветов {R,L,B} — R и L никогда не
  // соседствуют на настоящем кубике. Счётчики при этом остаются по 9 (просто
  // переставлены местами два существующих значения).
  const f = solvedFacelets();
  f.U[0] = 'R'; f.R[0] = 'U';
  const result = validateFacelets(f);
  assert.equal(result.valid, false);
  assert.equal(result.errors.length, 1);
  assert.equal(result.errors[0].code, 'IMPOSSIBLE_PIECE');
});

test('validateFacelets: CORNER_TWIST_PARITY при "провёрнутом" на месте уголке', () => {
  // Циклическая перестановка меток внутри одного и того же уголка (URF):
  // набор цветов уголка не меняется (та же фигура на том же месте), только
  // то, какая наклейка на какой грани — то есть его ориентация.
  const f = solvedFacelets();
  f.U[8] = 'F'; f.R[0] = 'U'; f.F[2] = 'R';
  const result = validateFacelets(f);
  assert.equal(result.valid, false);
  assert.deepEqual(result.errors.map((e) => e.code), ['CORNER_TWIST_PARITY']);
});

test('validateFacelets: EDGE_FLIP_PARITY при "перевёрнутом" на месте ребре', () => {
  // Обмен местами двух меток одного и того же ребра (UR): набор цветов
  // ребра тот же, меняется только ориентация.
  const f = solvedFacelets();
  f.U[5] = 'R'; f.R[1] = 'U';
  const result = validateFacelets(f);
  assert.equal(result.valid, false);
  assert.deepEqual(result.errors.map((e) => e.code), ['EDGE_FLIP_PARITY']);
});

test('validateFacelets: PERMUTATION_PARITY при обмене местами двух целых уголков', () => {
  // Уголки URF и ULB меняются идентичностями целиком (их 6 наклеек
  // перераспределены так, что физически они "поменялись местами") —
  // единственная транспозиция среди уголков при неизменных рёбрах.
  const f = solvedFacelets();
  f.R[0] = 'L'; f.F[2] = 'B'; f.L[0] = 'R'; f.B[2] = 'F';
  const result = validateFacelets(f);
  assert.equal(result.valid, false);
  assert.deepEqual(result.errors.map((e) => e.code), ['PERMUTATION_PARITY']);
});

test('validateFacelets: ранние проверки (структура/метки/центры/счётчики) останавливаются раньше физических', () => {
  const f = solvedFacelets();
  f.U[4] = 'R'; // сломан центр — до счётчиков/физики дело дойти не должно
  f.D[0] = 'X'; // и до метки D тоже (метки проверяются раньше центров)
  const result = validateFacelets(f);
  assert.equal(result.errors[0].code, 'UNKNOWN_LABEL');
});
