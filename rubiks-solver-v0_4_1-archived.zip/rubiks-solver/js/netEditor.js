// netEditor.js
// Ручной редактор развёртки кубика поверх facelets (см. HANDOFF.md §3.5).
// Как и capture.js, разделён на чистое headless-ядро (эта логика) и DOM
// потом навешивается отдельно поверх неё в демо-обвязке — сам этот файл
// не содержит рендеринга, только состояние и мутации facelets.
//
// Две операции редактирования:
// - "клик по наклейке" — цикл по 6 цветам (FACES), для точечных ошибок
//   распознавания/съёмки. Центр (индекс 4) редактировать нельзя — центр
//   зафиксирован как "якорь" цвета грани (см. validator.js: CENTER_MISMATCH),
//   поэтому вращение сетки 3x3 автоматически его не трогает.
// - "повернуть грань" — поворот всех 9 меток одной грани на 90°/180°/270°
//   как единого блока (для ошибок ориентации кадра при съёмке — кубик на
//   фото повёрнут, а не отдельная наклейка перепутана).
//
// Живая проверка собираемости — через validator.js#validateFacelets,
// вызывается заново после каждой мутации и отдаётся наружу через геттер.

import { FACES } from './engine.js';
import { validateFacelets, countLabels } from './validator.js';

export function cloneFacelets(facelets) {
  const out = {};
  for (const f of FACES) out[f] = [...facelets[f]];
  return out;
}

// Следующий цвет по кругу в фиксированном порядке FACES (U→R→F→D→L→B→U…).
export function nextLabel(label, step = 1) {
  const i = FACES.indexOf(label);
  if (i === -1) throw new Error('nextLabel: неизвестная метка ' + label);
  const n = FACES.length;
  return FACES[((i + step) % n + n) % n];
}

// Поворот сетки 3x3 (row-major, как facelets[face]) на 90° по часовой
// стрелке ровно один раз. Центр (индекс 4) неподвижен под любым поворотом.
export function rotateGridCW(grid) {
  const out = new Array(9);
  for (let r = 0; r < 3; r++) {
    for (let c = 0; c < 3; c++) {
      out[r * 3 + c] = grid[(2 - c) * 3 + r];
    }
  }
  return out;
}

// times может быть любым целым (в т.ч. отрицательным) — нормализуется по модулю 4.
export function rotateGridTimes(grid, times) {
  const n = ((times % 4) + 4) % 4;
  let out = grid;
  for (let i = 0; i < n; i++) out = rotateGridCW(out);
  return out;
}

export class NetEditor {
  constructor(facelets) {
    this.facelets = cloneFacelets(facelets);
  }

  get validation() {
    return validateFacelets(this.facelets);
  }

  get counts() {
    return countLabels(this.facelets);
  }

  // Цикл по цвету одной наклейки (не центра). step можно задать -1 для
  // обратного цикла (например, правый клик/долгое нажатие в UI).
  cycleSticker(face, index, step = 1) {
    if (index === 4) throw new Error('cycleSticker: центр грани редактировать нельзя');
    const cur = this.facelets[face][index];
    const next = nextLabel(cur, step);
    const arr = this.facelets[face].slice();
    arr[index] = next;
    this.facelets = { ...this.facelets, [face]: arr };
    return this.facelets;
  }

  // Прямая установка конкретного цвета (для будущего цветового пикера —
  // альтернатива циклу через cycleSticker).
  setSticker(face, index, label) {
    if (index === 4) throw new Error('setSticker: центр грани редактировать нельзя');
    if (!FACES.includes(label)) throw new Error('setSticker: неизвестная метка ' + label);
    const arr = this.facelets[face].slice();
    arr[index] = label;
    this.facelets = { ...this.facelets, [face]: arr };
    return this.facelets;
  }

  // Поворот всей грани как блока (ошибка ориентации при съёмке, не точечная).
  rotateFace(face, times = 1) {
    this.facelets = { ...this.facelets, [face]: rotateGridTimes(this.facelets[face], times) };
    return this.facelets;
  }

  reset(facelets) {
    this.facelets = cloneFacelets(facelets);
    return this.facelets;
  }
}
