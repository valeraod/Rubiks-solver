// tables.js
// Загрузка и декодирование move/pruning-таблиц Коциембы. Не завязан на способ
// чтения файла: в браузере передаётся fetchJson, читающий через fetch(), в
// Node.js (тесты, сборка) — через fs. Сам модуль только декодирует base64 в
// typed array нужного типа.

function base64ToUint8Array(base64) {
  if (typeof atob === 'function') {
    const binary = atob(base64);
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
    return bytes;
  }
  // eslint-disable-next-line no-undef
  return new Uint8Array(Buffer.from(base64, 'base64'));
}

const DTYPE_CTORS = { Uint8Array, Uint16Array, Uint32Array };

function decodePayload(payload) {
  const bytes = base64ToUint8Array(payload.data);
  const Ctor = DTYPE_CTORS[payload.dtype];
  if (!Ctor) throw new Error('tables.js: unknown dtype ' + payload.dtype);
  const bytesPerElement = Ctor.BYTES_PER_ELEMENT;
  // bytes may not be aligned for Uint16Array/Uint32Array views directly on its buffer
  // if byteOffset isn't a multiple of bytesPerElement; copy into a fresh aligned buffer.
  if (bytes.byteOffset % bytesPerElement !== 0) {
    const copy = new Uint8Array(bytes.length);
    copy.set(bytes);
    return new Ctor(copy.buffer, 0, payload.length);
  }
  return new Ctor(bytes.buffer, bytes.byteOffset, payload.length);
}

const TABLE_NAMES = [
  'twist-move', 'flip-move', 'udslice-move',
  'cornerperm-move', 'edgeperm8-move', 'sliceperm-move',
  'phase1-prun-twist-slice', 'phase1-prun-flip-slice',
  'phase2-prun-corner-slice', 'phase2-prun-edge8-slice',
];

/**
 * @param {(name: string) => Promise<object>} fetchJson - принимает имя файла без
 *   расширения (например 'twist-move') и должен вернуть распарсенный JSON.
 */
export async function loadTables(fetchJson) {
  const payloads = {};
  await Promise.all(TABLE_NAMES.map(async (name) => {
    payloads[name] = await fetchJson(name);
  }));

  return {
    twistMove: decodePayload(payloads['twist-move']),
    flipMove: decodePayload(payloads['flip-move']),
    udSliceMove: decodePayload(payloads['udslice-move']),
    cornerPermMove: decodePayload(payloads['cornerperm-move']),
    edgePerm8Move: decodePayload(payloads['edgeperm8-move']),
    slicePermMove: decodePayload(payloads['sliceperm-move']),
    prunTwistSlice: decodePayload(payloads['phase1-prun-twist-slice']),
    prunFlipSlice: decodePayload(payloads['phase1-prun-flip-slice']),
    prunCornerSlice: decodePayload(payloads['phase2-prun-corner-slice']),
    prunEdge8Slice: decodePayload(payloads['phase2-prun-edge8-slice']),
    meta: {
      allMoves: payloads['twist-move'].moves,
      phase2Moves: payloads['cornerperm-move'].moves,
      phase1MaxDepthTwistSlice: payloads['phase1-prun-twist-slice'].maxDepth,
      phase1MaxDepthFlipSlice: payloads['phase1-prun-flip-slice'].maxDepth,
      phase2MaxDepthCornerSlice: payloads['phase2-prun-corner-slice'].maxDepth,
      phase2MaxDepthEdge8Slice: payloads['phase2-prun-edge8-slice'].maxDepth,
    },
  };
}

/** Удобный fetchJson для Node.js (используется в тестах и скриптах сборки). */
export function nodeFetchJson(tablesDir) {
  return async (name) => {
    const fs = await import('fs');
    const path = await import('path');
    const filePath = path.join(tablesDir, name + '.json');
    return JSON.parse(fs.readFileSync(filePath, 'utf8'));
  };
}

/** Удобный fetchJson для браузера (используется в main.js). */
export function browserFetchJson(baseUrl) {
  return async (name) => {
    const res = await fetch(`${baseUrl}/${name}.json`);
    if (!res.ok) throw new Error('tables.js: failed to fetch ' + name + ' (' + res.status + ')');
    return res.json();
  };
}
