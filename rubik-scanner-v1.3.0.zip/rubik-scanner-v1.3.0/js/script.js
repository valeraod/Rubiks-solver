// ============================================================
// Rubik Face Scanner — клик по центру -> геометрия -> цвет
// Без нейросетей: flood fill (магическая палочка) + rotating
// calipers (аналог cv2.minAreaRect) + HSV-классификация.
// ============================================================

const REFERENCE_HSV = {
  yellow: { h: 55,  s: 200, v: 200 },
  orange: { h: 24,  s: 200, v: 200 },
  red:    { h: 0,   s: 200, v: 150 },
  blue:   { h: 210, s: 200, v: 150 },
  green:  { h: 120, s: 200, v: 120 },
};

const SWATCH_HEX = {
  white:  '#f2f3f5',
  yellow: '#f4d13d',
  red:    '#e0313d',
  orange: '#f08a24',
  blue:   '#2b5ce0',
  green:  '#2fae57',
  '???':  '#444a58',
};

// ---------- DOM ----------
const fileInput   = document.getElementById('fileInput');
const chooseBtn   = document.getElementById('chooseBtn');
const dropzone    = document.getElementById('dropzone');
const dropzoneInner = document.getElementById('dropzoneInner');
const stage       = document.getElementById('stage');
const canvasToolbar = document.getElementById('canvasToolbar');
const reuploadBtn = document.getElementById('reuploadBtn');
const photoCanvas = document.getElementById('photoCanvas');
const overlayCanvas = document.getElementById('overlayCanvas');
const statusEl    = document.getElementById('status');
const stepBanner  = document.getElementById('stepBanner');
const stepBadge   = document.getElementById('stepBadge');
const stepText    = document.getElementById('stepText');
const zoomOutBtn  = document.getElementById('zoomOutBtn');
const zoomInBtn   = document.getElementById('zoomInBtn');
const zoomResetBtn = document.getElementById('zoomResetBtn');
const zoomLabel   = document.getElementById('zoomLabel');

const ratioSlider = document.getElementById('ratioSlider');
const ratioValue  = document.getElementById('ratioValue');
const toleranceSlider = document.getElementById('toleranceSlider');
const toleranceValue  = document.getElementById('toleranceValue');

const swatchGrid  = document.getElementById('swatchGrid');
const faceletCode = document.getElementById('faceletCode');
const resultState = document.getElementById('resultState');
const resultFaceLabel = document.getElementById('resultFaceLabel');

const faceCross    = document.getElementById('faceCross');
const netProgress  = document.getElementById('netProgress');
const netDiagram   = document.getElementById('netDiagram');
const netExportState = document.getElementById('netExportState');
const faceletString  = document.getElementById('faceletString');
const copyStringBtn  = document.getElementById('copyStringBtn');
const resetAllBtn    = document.getElementById('resetAllBtn');
const netValidation  = document.getElementById('netValidation');

const pCtx = photoCanvas.getContext('2d', { willReadFrequently: true });
const oCtx = overlayCanvas.getContext('2d');

let naturalImageData = null; // ImageData на естественном разрешении
let naturalW = 0, naturalH = 0;
let fitScale = 1;
let zoomMultiplier = 1;
const ZOOM_STEP = 0.25, ZOOM_MIN = 0.5, ZOOM_MAX = 5;
let clickStage = 0; // 0 = ждём центр, 1 = ждём верхнюю наклейку
let centerPoint = null;
let lastCenterClick = null;
let lastUpClick = null;
let currentGrid = null;
let lastGridParams = null;
const CYCLE_COLORS = ['white', 'yellow', 'red', 'orange', 'blue', 'green'];

// ---------- мультиграневое сканирование ----------
const FACE_LABELS = ['U', 'L', 'F', 'R', 'B', 'D'];
const FACE_STRING_ORDER = ['U', 'R', 'F', 'D', 'L', 'B']; // канонический порядок facelet-строки
const FACE_POSITIONS = { U: [2, 1], L: [1, 2], F: [2, 2], R: [3, 2], B: [4, 2], D: [2, 3] };

let scannedFaces = {}; // label -> 3x3 массив {name}
let facePitches = {};  // label -> средний размер наклейки (px), для проверки согласованности между гранями
let currentFaceLabel = 'F';

initSwatchGrid();
initFaceCross();
wireEvents();

// ============================================================
// UI wiring
// ============================================================

function wireEvents() {
  chooseBtn.addEventListener('click', () => fileInput.click());
  fileInput.addEventListener('change', (e) => {
    if (e.target.files[0]) loadImageFile(e.target.files[0]);
  });

  ['dragover', 'dragenter'].forEach(evt =>
    dropzone.addEventListener(evt, (e) => {
      e.preventDefault();
      dropzoneInner.classList.add('drag');
    })
  );
  ['dragleave', 'drop'].forEach(evt =>
    dropzone.addEventListener(evt, (e) => {
      e.preventDefault();
      dropzoneInner.classList.remove('drag');
    })
  );
  dropzone.addEventListener('drop', (e) => {
    const f = e.dataTransfer.files[0];
    if (f) loadImageFile(f);
  });

  reuploadBtn.addEventListener('click', () => {
    stage.hidden = true;
    canvasToolbar.hidden = true;
    dropzone.hidden = false;
    fileInput.value = '';
    setStatus('ждёт фото', '');
    resetResults();
  });

  document.getElementById('restartBtn').addEventListener('click', restartClicks);

  zoomInBtn.addEventListener('click', () => zoomBy(ZOOM_STEP));
  zoomOutBtn.addEventListener('click', () => zoomBy(-ZOOM_STEP));
  zoomResetBtn.addEventListener('click', zoomResetToFit);

  // Ctrl/Cmd + колесо мыши — зум (обычное колесо остаётся для
  // прокрутки/панорамирования контейнера, как в обычном браузере)
  stage.addEventListener('wheel', (e) => {
    if (!e.ctrlKey && !e.metaKey) return;
    e.preventDefault();
    zoomBy(e.deltaY < 0 ? ZOOM_STEP : -ZOOM_STEP);
  }, { passive: false });

  swatchGrid.addEventListener('click', (e) => {
    const div = e.target.closest('.swatch');
    if (!div || div.classList.contains('empty')) return;
    const index = Array.prototype.indexOf.call(swatchGrid.children, div);
    cycleSwatchColor(index);
  });

  overlayCanvas.addEventListener('click', onCanvasClick);

  ratioSlider.addEventListener('input', () => {
    ratioValue.textContent = parseFloat(ratioSlider.value).toFixed(2);
    if (clickStage === 2) handleUpClick(lastUpClick.x, lastUpClick.y);
  });
  toleranceSlider.addEventListener('input', () => {
    toleranceValue.textContent = toleranceSlider.value;
    if (centerPoint && lastCenterClick) handleCenterClick(lastCenterClick.x, lastCenterClick.y);
  });
}

function setStatus(text, cls) {
  statusEl.textContent = text;
  statusEl.className = 'status mono' + (cls ? ' ' + cls : '');
}

function setStepBanner(badge, text, cls) {
  stepBanner.hidden = false;
  stepBadge.textContent = badge;
  stepText.textContent = text;
  stepBanner.className = 'step-banner' + (cls ? ' ' + cls : '');
}

// ============================================================
// Зум / панорамирование (важно для мелких/дальних фото — иначе
// клик по маленькой наклейке в большом кадре получается неточным)
// ============================================================

function computeFitScale() {
  const containerWidth = stage.clientWidth || 600;
  const maxDisplayHeight = window.innerHeight * 0.65;
  fitScale = Math.min(containerWidth / naturalW, maxDisplayHeight / naturalH);
  if (!isFinite(fitScale) || fitScale <= 0) fitScale = 1;
}

function applyZoom() {
  const scale = fitScale * zoomMultiplier;
  const w = Math.max(1, Math.round(naturalW * scale));
  const h = Math.max(1, Math.round(naturalH * scale));
  photoCanvas.style.width = w + 'px';
  photoCanvas.style.height = h + 'px';
  overlayCanvas.style.width = w + 'px';
  overlayCanvas.style.height = h + 'px';
  zoomLabel.textContent = Math.round(zoomMultiplier * 100) + '%';
}

function zoomBy(factor) {
  zoomMultiplier = Math.min(ZOOM_MAX, Math.max(ZOOM_MIN, zoomMultiplier + factor));
  applyZoom();
}

function zoomResetToFit() {
  zoomMultiplier = 1;
  applyZoom();
}

function initSwatchGrid() {
  swatchGrid.innerHTML = '';
  for (let i = 0; i < 9; i++) {
    const div = document.createElement('div');
    div.className = 'swatch empty';
    div.innerHTML = '<span></span>';
    swatchGrid.appendChild(div);
  }
}

function resetResults() {
  initSwatchGrid();
  faceletCode.innerHTML = '— — —<br>— — —<br>— — —';
  resultState.textContent = '—';
  resultState.className = 'mono result-state';
  currentGrid = null;
  lastGridParams = null;
}

// ============================================================
// Загрузка фото
// ============================================================

function loadImageFile(file) {
  const img = new Image();
  const url = URL.createObjectURL(file);
  img.onload = () => {
    naturalW = img.naturalWidth;
    naturalH = img.naturalHeight;

    photoCanvas.width = naturalW;
    photoCanvas.height = naturalH;
    overlayCanvas.width = naturalW;
    overlayCanvas.height = naturalH;

    pCtx.drawImage(img, 0, 0);
    naturalImageData = pCtx.getImageData(0, 0, naturalW, naturalH);

    oCtx.clearRect(0, 0, naturalW, naturalH);

    dropzone.hidden = true;
    stage.hidden = false;
    canvasToolbar.hidden = false;
    computeFitScale();
    zoomMultiplier = 1;
    applyZoom();
    setStepBanner('1 / 2', `Кликни по ЦЕНТРАЛЬНОЙ наклейке грани ${currentFaceLabel}`, '');
    setStatus('фото загружено', 'active');
    resetResults();
    URL.revokeObjectURL(url);
  };
  img.src = url;
}

// ============================================================
// Клик по канвасу -> перевод в естественные координаты
// ============================================================

function onCanvasClick(e) {
  const rect = overlayCanvas.getBoundingClientRect();
  const scaleX = naturalW / rect.width;
  const scaleY = naturalH / rect.height;
  const imgX = Math.round((e.clientX - rect.left) * scaleX);
  const imgY = Math.round((e.clientY - rect.top) * scaleY);

  if (clickStage === 0) {
    handleCenterClick(imgX, imgY);
  } else {
    handleUpClick(imgX, imgY);
  }
}

function restartClicks() {
  clickStage = 0;
  centerPoint = null;
  lastCenterClick = null;
  lastUpClick = null;
  oCtx.clearRect(0, 0, naturalW, naturalH);
  setStepBanner('1 / 2', `Кликни по ЦЕНТРАЛЬНОЙ наклейке грани ${currentFaceLabel}`, '');
  resetResults();
  setStatus('фото загружено', 'active');
}

// ============================================================
// Шаг 1: клик по центру -> flood fill + minAreaRect наклейки
// ============================================================

function handleCenterClick(imgX, imgY) {
  lastCenterClick = { x: imgX, y: imgY };
  const tolerance = parseFloat(toleranceSlider.value);
  const maxBound = Math.min(naturalW, naturalH) * 0.35;
  const flood = floodFill(naturalImageData, imgX, imgY, tolerance, maxBound);

  oCtx.clearRect(0, 0, naturalW, naturalH);

  if (flood.points.length < 30) {
    setStatus('не найдено', 'error');
    drawClickMarker(imgX, imgY, '#e0616b');
    resultState.textContent = 'кликни точнее по центру';
    resultState.className = 'mono result-state warn';
    return;
  }

  const rect = minAreaRect(flood.points);
  if (!rect) {
    setStatus('ошибка геометрии', 'error');
    return;
  }

  // Защита от "протёкшей" заливки: если flood fill прорвался через
  // белую рамку в белый/светлый фон (или в соседнюю ячейку), область
  // становится либо огромной, либо явно не квадратной, либо рыхлой
  // (дырявой) — solidity считает, насколько плотно точки заливки
  // заполняют свой же minAreaRect. Настоящая наклейка — плотное
  // почти-квадратное пятно, заметно меньше всего кадра.
  const imgArea = naturalW * naturalH;
  const areaRatio = flood.points.length / imgArea;
  const aspect = rect.width / rect.height;
  const solidity = flood.points.length / (rect.width * rect.height);

  let rejectReason = null;
  if (areaRatio > 0.09) rejectReason = 'область захватила больше 9% всего кадра';
  else if (aspect > 2.0 || aspect < 0.5) rejectReason = 'область сильно не квадратная (похоже на слияние нескольких наклеек)';
  else if (solidity < 0.55) rejectReason = 'область рыхлая/дырявая (похоже, залилось не сплошным пятном, а через фон)';

  if (rejectReason) {
    setStatus('заливка протекла', 'error');
    drawClickMarker(imgX, imgY, '#e0616b');
    drawRotatedSquare(rect.cx, rect.cy, rect, '#e0616b');
    resultState.textContent = 'область слишком большая/неровная';
    resultState.className = 'mono result-state warn';
    setStepBanner('1 / 2', `⚠ ${rejectReason} — уменьши "Допуск цвета" слева, увеличь зум и кликни точнее по центру`, 'warn');
    return;
  }

  centerPoint = { rect };
  clickStage = 1;

  // визуальная обратная связь: обводим найденную наклейку
  drawRotatedSquare(rect.cx, rect.cy, rect, '#4fd1c5');
  drawClickMarker(imgX, imgY, '#4fd1c5');

  // Совет (не блокирует): если размер сильно отличается от уже
  // отсканированных граней этого же кубика — вероятно, тоже утечка,
  // просто не хватившая жёстких порогов выше.
  const sizeAvg = (rect.width + rect.height) / 2;
  let sizeWarning = '';
  const otherPitches = Object.entries(facePitches)
    .filter(([label]) => label !== currentFaceLabel)
    .map(([, v]) => v);
  if (otherPitches.length >= 1) {
    const sorted = otherPitches.slice().sort((a, b) => a - b);
    const median = sorted[Math.floor(sorted.length / 2)];
    const ratio = sizeAvg / median;
    if (ratio > 2.2 || ratio < 0.45) {
      sizeWarning = ' ⚠ размер сильно отличается от других отсканированных граней — если рамка слева выглядит неверно, нажми "Заново"';
    }
  }

  setStepBanner('2 / 2', upClickInstructionFor(currentFaceLabel) + sizeWarning, sizeWarning ? 'warn' : '');
  setStatus('центр найден', 'active');
}

// ============================================================
// Шаг 2: клик "вверх" -> фиксируем ориентацию сетки, считаем всё
// ============================================================

function handleUpClick(imgX, imgY) {
  lastUpClick = { x: imgX, y: imgY };
  const rect = centerPoint.rect;
  const ratio = parseFloat(ratioSlider.value);

  // 4 кандидата направления по осям, найденным rotating calipers
  // (сам по себе minAreaRect не знает, какая из осей "верх")
  const angle = rect.angle;
  const axisA = [Math.cos(angle), Math.sin(angle)];
  const axisB = [-Math.sin(angle), Math.cos(angle)];
  const candidates = [axisA, [-axisA[0], -axisA[1]], axisB, [-axisB[0], -axisB[1]]];

  const dir = [imgX - rect.cx, imgY - rect.cy];
  const dirLen = Math.hypot(dir[0], dir[1]) || 1;
  const dirNorm = [dir[0] / dirLen, dir[1] / dirLen];

  let bestUp = candidates[0], bestDot = -Infinity;
  for (const c of candidates) {
    const dot = c[0] * dirNorm[0] + c[1] * dirNorm[1];
    if (dot > bestDot) { bestDot = dot; bestUp = c; }
  }

  const upVec = bestUp;
  const downVec = [-upVec[0], -upVec[1]];
  const rightVec = [-upVec[1], upVec[0]];

  const sizeAvg = (rect.width + rect.height) / 2;
  const pitch = sizeAvg / ratio;
  const patchHalf = Math.max(3, sizeAvg * 0.18);

  const grid = [];
  for (let rowOff = -1; rowOff <= 1; rowOff++) {
    const rowColors = [];
    for (let colOff = -1; colOff <= 1; colOff++) {
      const px = rect.cx + colOff * pitch * rightVec[0] + rowOff * pitch * downVec[0];
      const py = rect.cy + colOff * pitch * rightVec[1] + rowOff * pitch * downVec[1];
      const color = sampleMedianColor(naturalImageData, px, py, patchHalf);
      const name = color ? classifyColor(color.r, color.g, color.b) : '???';
      rowColors.push({ name, px, py });
    }
    grid.push(rowColors);
  }

  drawOverlay(grid, rightVec, downVec, pitch);
  lastGridParams = { rightVec, downVec, pitch };
  renderResults(grid);
  saveScannedFace(currentFaceLabel, grid);
  facePitches[currentFaceLabel] = sizeAvg;

  clickStage = 2; // готово; следующий клик по canvas запустит restartClicks через кнопку
  setStepBanner('готово', `Грань ${currentFaceLabel} распознана. Неверный цвет? Клик по квадрату справа — исправить. Выбери следующую грань выше.`, 'done');
  setStatus('распознано', 'active');
}

// ============================================================
// Flood fill (магическая палочка) — стек, ограниченный bbox
// ============================================================

function floodFill(imageData, seedX, seedY, tolerance, maxRadius) {
  const { data, width, height } = imageData;
  seedX = Math.round(seedX);
  seedY = Math.round(seedY);
  if (seedX < 0 || seedY < 0 || seedX >= width || seedY >= height) {
    return { points: [] };
  }

  const seedIdx = (seedY * width + seedX) * 4;
  const seed = [data[seedIdx], data[seedIdx + 1], data[seedIdx + 2]];

  const minX = Math.max(0, Math.floor(seedX - maxRadius));
  const maxX = Math.min(width - 1, Math.ceil(seedX + maxRadius));
  const minY = Math.max(0, Math.floor(seedY - maxRadius));
  const maxY = Math.min(height - 1, Math.ceil(seedY + maxRadius));

  const visited = new Uint8Array(width * height);
  const stack = [[seedX, seedY]];
  visited[seedY * width + seedX] = 1;
  const points = [];
  const tol2 = tolerance * tolerance;

  while (stack.length) {
    const [x, y] = stack.pop();
    points.push([x, y]);

    const neighbors = [[x + 1, y], [x - 1, y], [x, y + 1], [x, y - 1]];
    for (const [nx, ny] of neighbors) {
      if (nx < minX || nx > maxX || ny < minY || ny > maxY) continue;
      const vIdx = ny * width + nx;
      if (visited[vIdx]) continue;
      const idx = vIdx * 4;
      const dr = data[idx] - seed[0];
      const dg = data[idx + 1] - seed[1];
      const db = data[idx + 2] - seed[2];
      const dist2 = dr * dr + dg * dg + db * db;
      if (dist2 <= tol2 * 3) {
        visited[vIdx] = 1;
        stack.push([nx, ny]);
      }
    }
  }

  return { points };
}

// ============================================================
// Convex hull (monotone chain) + rotating calipers min-area-rect
// Аналог cv2.minAreaRect: угол берётся из ориентации рёбер
// выпуклой оболочки, а не из PCA (для квадрата PCA даёт
// нестабильный угол — дисперсия почти одинакова по всем осям).
// ============================================================

function convexHull(points) {
  const pts = points.slice().sort((a, b) => (a[0] - b[0]) || (a[1] - b[1]));
  const n = pts.length;
  if (n < 3) return pts;

  const cross = (o, a, b) => (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0]);

  const lower = [];
  for (const p of pts) {
    while (lower.length >= 2 && cross(lower[lower.length - 2], lower[lower.length - 1], p) <= 0) {
      lower.pop();
    }
    lower.push(p);
  }
  const upper = [];
  for (let i = n - 1; i >= 0; i--) {
    const p = pts[i];
    while (upper.length >= 2 && cross(upper[upper.length - 2], upper[upper.length - 1], p) <= 0) {
      upper.pop();
    }
    upper.push(p);
  }
  upper.pop();
  lower.pop();
  return lower.concat(upper);
}

function minAreaRect(rawPoints) {
  // сабсэмплинг для скорости на крупных регионах
  const points = rawPoints.length > 4000
    ? rawPoints.filter((_, i) => i % Math.ceil(rawPoints.length / 4000) === 0)
    : rawPoints;

  const hull = convexHull(points);
  if (hull.length < 3) return null;

  let best = null;

  for (let i = 0; i < hull.length; i++) {
    const p1 = hull[i];
    const p2 = hull[(i + 1) % hull.length];
    const edgeAngle = Math.atan2(p2[1] - p1[1], p2[0] - p1[0]);

    const cos = Math.cos(-edgeAngle);
    const sin = Math.sin(-edgeAngle);

    let minX = Infinity, maxX = -Infinity, minY = Infinity, maxY = -Infinity;
    for (const p of hull) {
      const rx = p[0] * cos - p[1] * sin;
      const ry = p[0] * sin + p[1] * cos;
      if (rx < minX) minX = rx;
      if (rx > maxX) maxX = rx;
      if (ry < minY) minY = ry;
      if (ry > maxY) maxY = ry;
    }

    const w = maxX - minX;
    const h = maxY - minY;
    const area = w * h;

    if (!best || area < best.area) {
      // центр прямоугольника в повёрнутых координатах -> обратно в исходные
      const ccx = (minX + maxX) / 2;
      const ccy = (minY + maxY) / 2;
      const cosBack = Math.cos(edgeAngle);
      const sinBack = Math.sin(edgeAngle);
      const cx = ccx * cosBack - ccy * sinBack;
      const cy = ccx * sinBack + ccy * cosBack;

      best = { area, width: w, height: h, angle: edgeAngle, cx, cy };
    }
  }

  // нормализация: работаем с более длинной стороной как "width"
  // направление u в коде выше не завязано на which-is-longer,
  // так что просто возвращаем как есть
  return best;
}

// ============================================================
// Сэмплинг цвета маленького патча (в естественных координатах)
// ============================================================

function sampleMedianColor(imageData, cx, cy, halfSize) {
  const { data, width, height } = imageData;
  const x0 = Math.max(0, Math.round(cx - halfSize));
  const x1 = Math.min(width - 1, Math.round(cx + halfSize));
  const y0 = Math.max(0, Math.round(cy - halfSize));
  const y1 = Math.min(height - 1, Math.round(cy + halfSize));

  if (x1 <= x0 || y1 <= y0) return null;

  const rs = [], gs = [], bs = [];
  for (let y = y0; y <= y1; y++) {
    for (let x = x0; x <= x1; x++) {
      const idx = (y * width + x) * 4;
      rs.push(data[idx]);
      gs.push(data[idx + 1]);
      bs.push(data[idx + 2]);
    }
  }
  return { r: median(rs), g: median(gs), b: median(bs) };
}

function median(arr) {
  const sorted = arr.slice().sort((a, b) => a - b);
  const mid = Math.floor(sorted.length / 2);
  return sorted.length % 2 ? sorted[mid] : (sorted[mid - 1] + sorted[mid]) / 2;
}

// ============================================================
// HSV классификация (порт python-версии)
// ============================================================

function rgbToHsv(r, g, b) {
  r /= 255; g /= 255; b /= 255;
  const max = Math.max(r, g, b), min = Math.min(r, g, b);
  const d = max - min;
  let h = 0;
  if (d !== 0) {
    if (max === r) h = ((g - b) / d) % 6;
    else if (max === g) h = (b - r) / d + 2;
    else h = (r - g) / d + 4;
    h *= 60;
    if (h < 0) h += 360;
  }
  const s = max === 0 ? 0 : d / max;
  const v = max;
  return { h, s: s * 255, v: v * 255 }; // s,v в масштабе 0-255 как в python-версии
}

function classifyColor(r, g, b) {
  const { h, s, v } = rgbToHsv(r, g, b);

  if (s < 60 && v > 140) return 'white';

  let best = null, bestDist = Infinity;
  for (const name in REFERENCE_HSV) {
    const ref = REFERENCE_HSV[name];
    const dh = Math.min(Math.abs(h - ref.h), 360 - Math.abs(h - ref.h));
    const dist = dh * 1.0 + Math.abs(s - ref.s) * 0.5 + Math.abs(v - ref.v) * 0.3;
    if (dist < bestDist) { bestDist = dist; best = name; }
  }
  return best;
}

// ============================================================
// Отрисовка overlay на канвасе
// ============================================================

function drawClickMarker(x, y, color) {
  oCtx.strokeStyle = color;
  oCtx.lineWidth = 3;
  oCtx.beginPath();
  oCtx.arc(x, y, 14, 0, Math.PI * 2);
  oCtx.stroke();
  oCtx.beginPath();
  oCtx.moveTo(x - 20, y); oCtx.lineTo(x + 20, y);
  oCtx.moveTo(x, y - 20); oCtx.lineTo(x, y + 20);
  oCtx.stroke();
}

function drawRotatedSquare(cx, cy, rect, color) {
  const angle = rect.angle;
  const axisA = [Math.cos(angle), Math.sin(angle)];
  const axisB = [-Math.sin(angle), Math.cos(angle)];
  const hw = rect.width / 2, hh = rect.height / 2;
  const corners = [
    [cx - hw * axisA[0] - hh * axisB[0], cy - hw * axisA[1] - hh * axisB[1]],
    [cx + hw * axisA[0] - hh * axisB[0], cy + hw * axisA[1] - hh * axisB[1]],
    [cx + hw * axisA[0] + hh * axisB[0], cy + hw * axisA[1] + hh * axisB[1]],
    [cx - hw * axisA[0] + hh * axisB[0], cy - hw * axisA[1] + hh * axisB[1]],
  ];
  oCtx.strokeStyle = color;
  oCtx.lineWidth = 2.5;
  oCtx.setLineDash([6, 4]);
  oCtx.beginPath();
  oCtx.moveTo(corners[0][0], corners[0][1]);
  for (let i = 1; i < 4; i++) oCtx.lineTo(corners[i][0], corners[i][1]);
  oCtx.closePath();
  oCtx.stroke();
  oCtx.setLineDash([]);
}

function drawOverlay(grid, rightVec, downVec, pitch) {
  oCtx.clearRect(0, 0, naturalW, naturalH);

  const half = pitch * 0.42;

  oCtx.strokeStyle = '#4fd1c5';
  oCtx.lineWidth = 2.5;
  oCtx.shadowColor = 'rgba(79,209,197,0.8)';
  oCtx.shadowBlur = 4;

  for (const row of grid) {
    for (const cell of row) {
      const corners = [
        [cell.px - half * rightVec[0] - half * downVec[0], cell.py - half * rightVec[1] - half * downVec[1]],
        [cell.px + half * rightVec[0] - half * downVec[0], cell.py + half * rightVec[1] - half * downVec[1]],
        [cell.px + half * rightVec[0] + half * downVec[0], cell.py + half * rightVec[1] + half * downVec[1]],
        [cell.px - half * rightVec[0] + half * downVec[0], cell.py - half * rightVec[1] + half * downVec[1]],
      ];
      oCtx.beginPath();
      oCtx.moveTo(corners[0][0], corners[0][1]);
      for (let i = 1; i < 4; i++) oCtx.lineTo(corners[i][0], corners[i][1]);
      oCtx.closePath();
      oCtx.stroke();
    }
  }
  oCtx.shadowBlur = 0;

  // подписи цвета
  oCtx.font = '600 15px Inter, sans-serif';
  oCtx.textAlign = 'center';
  for (const row of grid) {
    for (const cell of row) {
      oCtx.fillStyle = 'rgba(0,0,0,0.65)';
      const textY = cell.py + 5;
      const label = cell.name;
      const textW = oCtx.measureText(label).width;
      oCtx.fillRect(cell.px - textW / 2 - 6, textY - 15, textW + 12, 20);
      oCtx.fillStyle = '#fff';
      oCtx.fillText(label, cell.px, textY);
    }
  }
}

// ============================================================
// Обновление панели результатов
// ============================================================

function renderResults(grid) {
  currentGrid = grid;
  const cells = swatchGrid.children;
  let i = 0;
  const codeRows = [];
  let unknownCount = 0;

  for (const row of grid) {
    const rowLetters = [];
    for (const cell of row) {
      const div = cells[i];
      div.className = 'swatch' + (cell.manual ? ' manual' : '');
      div.style.background = SWATCH_HEX[cell.name] || '#444';
      div.querySelector('span').textContent = cell.name;
      if (cell.name === '???') unknownCount++;
      rowLetters.push(letterFor(cell.name));
      i++;
    }
    codeRows.push(rowLetters.join(' '));
  }

  faceletCode.innerHTML = codeRows.join('<br>');

  if (unknownCount > 0) {
    resultState.textContent = `${unknownCount} не определено`;
    resultState.className = 'mono result-state warn';
  } else {
    resultState.textContent = 'готово';
    resultState.className = 'mono result-state ok';
  }
}

function letterFor(name) {
  return { white: 'W', yellow: 'Y', red: 'R', orange: 'O', blue: 'B', green: 'G', '???': '?' }[name] || '?';
}

function cycleSwatchColor(index) {
  if (!currentGrid) return;
  const row = Math.floor(index / 3);
  const col = index % 3;
  const cell = currentGrid[row][col];
  const curIdx = CYCLE_COLORS.indexOf(cell.name);
  cell.name = CYCLE_COLORS[(curIdx + 1) % CYCLE_COLORS.length];
  cell.manual = true;

  renderResults(currentGrid);
  if (lastGridParams) {
    drawOverlay(currentGrid, lastGridParams.rightVec, lastGridParams.downVec, lastGridParams.pitch);
  }
  if (scannedFaces[currentFaceLabel]) {
    saveScannedFace(currentFaceLabel, currentGrid);
  }
}

// ============================================================
// Мультиграневое сканирование: селектор граней (крест) + развёртка
// ============================================================

function initFaceCross() {
  faceCross.innerHTML = '';
  for (const label of FACE_LABELS) {
    const [col, row] = FACE_POSITIONS[label];
    const slot = document.createElement('div');
    slot.className = 'face-slot';
    slot.dataset.label = label;
    slot.style.gridColumn = col;
    slot.style.gridRow = row;
    slot.innerHTML = `<span class="face-letter">${label}</span>`;
    slot.addEventListener('click', () => selectFace(label));
    faceCross.appendChild(slot);
  }
  renderFaceCross();
}

function renderFaceCross() {
  for (const slot of faceCross.children) {
    const label = slot.dataset.label;
    const done = !!scannedFaces[label];
    slot.classList.toggle('done', done);
    slot.classList.toggle('active', label === currentFaceLabel);

    const oldGrid = slot.querySelector('.mini-grid');
    if (oldGrid) oldGrid.remove();

    if (done) {
      const mini = document.createElement('div');
      mini.className = 'mini-grid';
      for (const row of scannedFaces[label]) {
        for (const cell of row) {
          const d = document.createElement('div');
          d.style.background = SWATCH_HEX[cell.name] || '#444';
          mini.appendChild(d);
        }
      }
      slot.appendChild(mini);
    }
  }
  const doneCount = Object.keys(scannedFaces).length;
  netProgress.textContent = `${doneCount} / 6 отсканировано`;
}

function selectFace(label) {
  currentFaceLabel = label;
  resultFaceLabel.textContent = `Распознанная грань — ${label}`;
  renderFaceCross();

  // сброс текущего состояния канваса под новую грань — нужно новое фото
  dropzone.hidden = false;
  stage.hidden = true;
  canvasToolbar.hidden = true;
  stepBanner.hidden = true;
  fileInput.value = '';
  clickStage = 0;
  centerPoint = null;
  lastCenterClick = null;
  lastUpClick = null;
  resetResults();
  setStatus('ждёт фото', '');
}

function upClickInstructionFor(label) {
  if (label === 'U') return 'Кликни по наклейке, ближайшей к ЗАДНЕЙ грани (B)';
  if (label === 'D') return 'Кликни по наклейке, ближайшей к ПЕРЕДНЕЙ грани (F)';
  return 'Кликни по наклейке, ближайшей к ВЕРХНЕЙ грани (U)';
}

function saveScannedFace(label, grid) {
  // сохраняем независимую копию (без px/py — они привязаны к конкретному фото)
  scannedFaces[label] = grid.map(row => row.map(cell => ({ name: cell.name, manual: !!cell.manual })));
  renderFaceCross();
  updateNetExport();
}

function renderNetFace(container, grid) {
  container.innerHTML = '';
  container.classList.remove('placeholder');
  for (const row of grid) {
    for (const cell of row) {
      const d = document.createElement('div');
      d.style.background = SWATCH_HEX[cell.name] || '#444';
      container.appendChild(d);
    }
  }
}

function updateNetExport() {
  // ---- диаграмма ----
  netDiagram.innerHTML = '';
  for (const label of FACE_LABELS) {
    const [col, row] = FACE_POSITIONS[label];
    const el = document.createElement('div');
    el.style.gridColumn = col;
    el.style.gridRow = row;
    if (scannedFaces[label]) {
      el.className = 'net-face';
      renderNetFace(el, scannedFaces[label]);
    } else {
      el.className = 'net-face placeholder';
      el.innerHTML = `<span>${label}</span>`;
    }
    netDiagram.appendChild(el);
  }

  const doneCount = Object.keys(scannedFaces).length;
  if (doneCount < 6) {
    netExportState.textContent = `жду остальные грани (${doneCount}/6)`;
    netExportState.className = 'mono net-export-state';
    faceletString.value = '';
    netValidation.textContent = '';
    netValidation.className = 'mono net-validation';
    return;
  }

  // ---- все 6 граней есть -> строим facelet-строку ----
  const centerColorToLabel = {};
  for (const label of FACE_LABELS) {
    centerColorToLabel[scannedFaces[label][1][1].name] = label;
  }

  const distinctCenters = Object.keys(centerColorToLabel).length;
  const colorCounts = {};
  let unresolved = 0;

  let str = '';
  for (const label of FACE_STRING_ORDER) {
    for (const row of scannedFaces[label]) {
      for (const cell of row) {
        colorCounts[cell.name] = (colorCounts[cell.name] || 0) + 1;
        const letter = centerColorToLabel[cell.name];
        if (letter) {
          str += letter;
        } else {
          str += '?';
          unresolved++;
        }
      }
    }
  }

  faceletString.value = str;

  // ---- валидация ----
  const problems = [];
  if (distinctCenters < 6) {
    problems.push(`У двух граней совпадает цвет центра (различных цветов центров: ${distinctCenters} из 6) — проверь сканирование.`);
  }
  if (unresolved > 0) {
    problems.push(`${unresolved} наклеек имеют цвет, не совпадающий ни с одним центром — поправь их вручную (клик по квадрату).`);
  }
  for (const color in colorCounts) {
    if (colorCounts[color] !== 9) {
      problems.push(`Цвет "${color}": ${colorCounts[color]} наклеек вместо 9.`);
    }
  }

  if (problems.length === 0) {
    netExportState.textContent = 'готово, валидно';
    netExportState.className = 'mono net-export-state ok';
    netValidation.textContent = 'Проверка пройдена: 6 различных центров, каждый цвет встречается ровно 9 раз.';
    netValidation.className = 'mono net-validation ok';
  } else {
    netExportState.textContent = 'есть несостыковки';
    netExportState.className = 'mono net-export-state';
    netValidation.textContent = problems.join('\n');
    netValidation.className = 'mono net-validation warn';
  }
}

function wireNetEvents() {
  copyStringBtn.addEventListener('click', async () => {
    if (!faceletString.value) return;
    try {
      await navigator.clipboard.writeText(faceletString.value);
      copyStringBtn.textContent = 'Скопировано ✓';
      setTimeout(() => { copyStringBtn.textContent = 'Скопировать'; }, 1500);
    } catch (e) {
      faceletString.select();
      document.execCommand('copy');
    }
  });

  resetAllBtn.addEventListener('click', () => {
    scannedFaces = {};
    facePitches = {};
    currentFaceLabel = 'F';
    renderFaceCross();
    updateNetExport();
    selectFace('F');
  });
}

wireNetEvents();
selectFace('F');
