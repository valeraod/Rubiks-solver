// solve.js
// Оркестратор: кубик (engine.js) -> координаты -> фаза 1 -> применить к кубику
// -> координаты для фазы 2 -> фаза 2 -> применить -> проверить, что собран.

import * as E from '../engine.js';
import { computeAllCoordinates } from './coordinates.js';
import { solvePhase1 } from './phase1.js';
import { solvePhase2 } from './phase2.js';
import { optimizeMoves } from './moveOptimizer.js';

/**
 * @param {object[]} inputCube - кубик в формате engine.js (не мутируется)
 * @param {object} tables - результат loadTables()
 * @param {object} [opts]
 * @param {number} [opts.phase1MaxBound]
 * @param {number} [opts.phase2MaxBound]
 * @returns {{ solved: boolean, moves: string[], phase1Moves: string[], phase2Moves: string[] }}
 */
export function solveCube(inputCube, tables, opts = {}) {
  const cube = E.cloneCube(inputCube);

  const startCoords = computeAllCoordinates(cube);
  const phase1Moves = solvePhase1(startCoords, tables, opts.phase1MaxBound ?? 12);
  if (!phase1Moves) {
    return { solved: false, moves: [], phase1Moves: null, phase2Moves: null, error: 'Фаза 1 не найдена (некорректный кубик?)' };
  }
  E.applyMoves(cube, phase1Moves);

  const midCoords = computeAllCoordinates(cube);
  const phase2Moves = solvePhase2(midCoords, tables, opts.phase2MaxBound ?? 18);
  if (!phase2Moves) {
    return { solved: false, moves: [], phase1Moves, phase2Moves: null, error: 'Фаза 2 не найдена (внутренняя ошибка)' };
  }
  E.applyMoves(cube, phase2Moves);

  const solved = E.isSolved(cube);
  const moves = optimizeMoves([...phase1Moves, ...phase2Moves]);

  return { solved, moves, phase1Moves, phase2Moves };
}
