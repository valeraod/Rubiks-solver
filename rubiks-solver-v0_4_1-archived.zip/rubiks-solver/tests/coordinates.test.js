import test from 'node:test';
import assert from 'node:assert/strict';
import * as E from '../js/engine.js';
import * as C from '../js/kociemba/coordinates.js';

test('solved cube has all-zero coordinates (except udSlice at its fixed solved value)', () => {
  const cube = E.newSolvedCube();
  const coords = C.computeAllCoordinates(cube);
  assert.equal(coords.twist, 0);
  assert.equal(coords.flip, 0);
  assert.equal(coords.cornerPerm, 0);
  assert.equal(coords.edgePerm8, 0);
  assert.equal(coords.slicePerm, 0);
  assert.equal(coords.udSlice, C.SOLVED_UD_SLICE);
});

test('permutation encode/decode round-trips for n=8 and n=12', () => {
  for (const n of [8, 12]) {
    const fact = (k) => (k <= 1 ? 1 : k * fact(k - 1));
    const max = fact(n);
    for (let t = 0; t < 50; t++) {
      const idx = Math.floor(Math.random() * max);
      const perm = C.indexToPermutation(idx, n);
      assert.equal(new Set(perm).size, n, 'perm must be a valid permutation');
      const idx2 = C.permutationToIndex(perm);
      assert.equal(idx2, idx, `mismatch for n=${n}`);
    }
  }
});

test('orientation encode/decode round-trips for (base=3,count=8) and (base=2,count=12)', () => {
  for (const [base, count] of [[3, 8], [2, 12]]) {
    const max = Math.pow(base, count - 1);
    for (let t = 0; t < 50; t++) {
      const idx = Math.floor(Math.random() * max);
      const ori = C.indexToOrientation(idx, base, count);
      const sum = ori.reduce((a, b) => a + b, 0);
      assert.equal(sum % base, 0, 'derived last digit must satisfy sum % base == 0');
      const idx2 = C.orientationToIndex(ori, base, count);
      assert.equal(idx2, idx);
    }
  }
});

test('combination encode/decode round-trips over the full C(12,4)=495 range', () => {
  const n = 12, k = 4;
  const max = C.binomial(n, k);
  assert.equal(max, 495);
  for (let idx = 0; idx < max; idx++) {
    const marked = C.indexToCombination(idx, n, k);
    assert.equal(marked.reduce((a, b) => a + b, 0), k);
    const idx2 = C.combinationToIndex(marked, k);
    assert.equal(idx2, idx);
  }
});

test('corner orientation sum is always divisible by 3, edge orientation sum always by 2 (random scrambles)', () => {
  const moveset = [];
  for (const f of ['U', 'D', 'L', 'R', 'F', 'B']) for (const m of ['', "'", '2']) moveset.push(f + m);
  function randScramble(n) {
    const a = [];
    for (let i = 0; i < n; i++) a.push(moveset[Math.floor(Math.random() * moveset.length)]);
    return a;
  }
  for (let t = 0; t < 50; t++) {
    const cube = E.newSolvedCube();
    E.applyMoves(cube, randScramble(25));
    const { ori: cornerOri } = C.readCorners(cube);
    const { ori: edgeOri } = C.readEdges(cube);
    assert.equal(cornerOri.reduce((a, b) => a + b, 0) % 3, 0);
    assert.equal(edgeOri.reduce((a, b) => a + b, 0) % 2, 0);
  }
});

test('classic fact: U/D moves never twist corners or flip edges; L/R/F/B twist exactly 4 corners; F/B flip exactly 4 edges', () => {
  for (const mv of ['U', 'D']) {
    const cube = E.newSolvedCube();
    E.applyMove(cube, mv);
    const { ori: cornerOri } = C.readCorners(cube);
    const { ori: edgeOri } = C.readEdges(cube);
    assert.ok(cornerOri.every((o) => o === 0), `${mv} should not twist any corner`);
    assert.ok(edgeOri.every((o) => o === 0), `${mv} should not flip any edge`);
  }
  for (const mv of ['L', 'R', 'F', 'B']) {
    const cube = E.newSolvedCube();
    E.applyMove(cube, mv);
    const { ori: cornerOri } = C.readCorners(cube);
    assert.equal(cornerOri.filter((o) => o !== 0).length, 4, `${mv} should twist exactly 4 corners`);
  }
  for (const mv of ['F', 'B']) {
    const cube = E.newSolvedCube();
    E.applyMove(cube, mv);
    const { ori: edgeOri } = C.readEdges(cube);
    assert.equal(edgeOri.filter((o) => o !== 0).length, 4, `${mv} should flip exactly 4 edges`);
  }
  for (const mv of ['L', 'R']) {
    const cube = E.newSolvedCube();
    E.applyMove(cube, mv);
    const { ori: edgeOri } = C.readEdges(cube);
    assert.equal(edgeOri.filter((o) => o !== 0).length, 0, `${mv} should not flip any edge`);
  }
});

test('sequences of only U/D moves never disturb twist/flip/udSlice (they stay solved-like)', () => {
  const moveset = ['U', "U'", 'U2', 'D', "D'", 'D2'];
  for (let t = 0; t < 20; t++) {
    const cube = E.newSolvedCube();
    const seq = [];
    for (let i = 0; i < 15; i++) seq.push(moveset[Math.floor(Math.random() * moveset.length)]);
    E.applyMoves(cube, seq);
    const coords = C.computeAllCoordinates(cube);
    assert.equal(coords.twist, 0, 'seq: ' + seq.join(' '));
    assert.equal(coords.flip, 0, 'seq: ' + seq.join(' '));
    assert.equal(coords.udSlice, C.SOLVED_UD_SLICE, 'seq: ' + seq.join(' '));
  }
});

test('computeAllCoordinates stays within valid ranges across 200 random scrambles', () => {
  const moveset = [];
  for (const f of ['U', 'D', 'L', 'R', 'F', 'B']) for (const m of ['', "'", '2']) moveset.push(f + m);
  function randScramble(n) {
    const a = [];
    for (let i = 0; i < n; i++) a.push(moveset[Math.floor(Math.random() * moveset.length)]);
    return a;
  }
  for (let t = 0; t < 200; t++) {
    const cube = E.newSolvedCube();
    E.applyMoves(cube, randScramble(30));
    const cd = C.computeAllCoordinates(cube);
    assert.ok(cd.twist >= 0 && cd.twist < 2187);
    assert.ok(cd.flip >= 0 && cd.flip < 2048);
    assert.ok(cd.udSlice >= 0 && cd.udSlice < 495);
    assert.ok(cd.cornerPerm >= 0 && cd.cornerPerm < 40320);
    assert.ok(cd.edgePerm8 >= 0 && cd.edgePerm8 < 40320);
    assert.ok(cd.slicePerm >= 0 && cd.slicePerm < 24);
  }
});
