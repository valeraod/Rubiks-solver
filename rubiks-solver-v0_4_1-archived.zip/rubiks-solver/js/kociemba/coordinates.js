// coordinates.js
// Вычисление координат Коциембы из кубика engine.js.
//
// Правила ориентации проверены эмпирически (см. HANDOFF.md, раздел 3.2, и
// tests/coordinates.test.js): против инвариантов чётности (сумма ориентаций
// углов кратна 3, сумма ориентаций рёбер кратна 2, для случайных скрамблов)
// и против классических фактов (U/D никогда не переворачивают/крутят фигуры;
// F/B переворачивают ровно 4 ребра; L/R/F/B крутят ровно 4 угла).

// ---- Канонические идентичности и позиции (порядок фиксирован произвольно,
// используется только внутри этого модуля и таблиц на его основе) ----

export const CORNER_IDENTITIES = [
  ['U', 'R', 'F'], ['U', 'F', 'L'], ['U', 'L', 'B'], ['U', 'B', 'R'],
  ['D', 'F', 'R'], ['D', 'L', 'F'], ['D', 'B', 'L'], ['D', 'R', 'B'],
];
export const CORNER_POSITIONS = [
  [1, 1, 1], [-1, 1, 1], [-1, 1, -1], [1, 1, -1],
  [1, -1, 1], [-1, -1, 1], [-1, -1, -1], [1, -1, -1],
];

export const EDGE_IDENTITIES = [
  ['U', 'R'], ['U', 'F'], ['U', 'L'], ['U', 'B'],
  ['D', 'R'], ['D', 'F'], ['D', 'L'], ['D', 'B'],
  ['F', 'R'], ['F', 'L'], ['B', 'L'], ['B', 'R'],
];
export const EDGE_POSITIONS = [
  [1, 1, 0], [0, 1, 1], [-1, 1, 0], [0, 1, -1],
  [1, -1, 0], [0, -1, 1], [-1, -1, 0], [0, -1, -1],
  [1, 0, 1], [-1, 0, 1], [-1, 0, -1], [1, 0, -1],
];

// индексы 8..11 в EDGE_IDENTITIES/EDGE_POSITIONS — это "экваториальные" рёбра
// (не касаются U/D), используются в UD-slice координатах фазы 1 и фазы 2.
export const SLICE_EDGE_START = 8;

// значение координаты udSlice, соответствующее собранному кубику (экваториальные
// рёбра занимают последние 4 из 12 позиций => максимальный индекс в нашей
// кодировке, проверено тестами)
export const SOLVED_UD_SLICE = 494;

function axisOfNormal(s) {
  return s.fx !== 0 ? 'x' : s.fy !== 0 ? 'y' : 'z';
}

function setEq(a, b) {
  const sa = [...a].sort().join('');
  const sb = [...b].sort().join('');
  return sa === sb;
}

// ---- Извлечение "сырых" перестановок/ориентаций из кубика engine.js ----

/**
 * @param {object[]} cube - массив наклеек из engine.js
 * @returns {{ perm: number[8], ori: number[8] }}
 *   perm[slot] = индекс идентичности (0..7) фигуры, находящейся в слоте slot
 *   ori[slot] = ориентация (0..2) этой фигуры
 */
export function readCorners(cube) {
  const perm = new Array(8).fill(-1);
  const ori = new Array(8).fill(0);

  for (let slot = 0; slot < 8; slot++) {
    const [x, y, z] = CORNER_POSITIONS[slot];
    const trio = cube.filter((s) => s.x === x && s.y === y && s.z === z);
    const homes = trio.map((s) => s.home);
    const identityIdx = CORNER_IDENTITIES.findIndex((ids) => setEq(ids, homes));
    if (identityIdx === -1) throw new Error('readCorners: no matching identity at slot ' + slot);
    perm[slot] = identityIdx;

    const primary = trio.find((s) => s.home === 'U' || s.home === 'D');
    const axis = axisOfNormal(primary);
    const parity = x * y * z;
    const cycle = parity === 1 ? ['y', 'x', 'z'] : ['y', 'z', 'x'];
    ori[slot] = cycle.indexOf(axis);
  }
  return { perm, ori };
}

/**
 * @returns {{ perm: number[12], ori: number[12] }}
 */
export function readEdges(cube) {
  const perm = new Array(12).fill(-1);
  const ori = new Array(12).fill(0);

  for (let slot = 0; slot < 12; slot++) {
    const [x, y, z] = EDGE_POSITIONS[slot];
    const pair = cube.filter((s) => s.x === x && s.y === y && s.z === z);
    const homes = pair.map((s) => s.home);
    const identityIdx = EDGE_IDENTITIES.findIndex((ids) => setEq(ids, homes));
    if (identityIdx === -1) throw new Error('readEdges: no matching identity at slot ' + slot);
    perm[slot] = identityIdx;

    const sticker0 = pair.find((s) => s.home === 'U' || s.home === 'D')
      || pair.find((s) => s.home === 'F' || s.home === 'B');
    const axis = axisOfNormal(sticker0);
    const positionAxis = Math.abs(y) === 1 ? 'y' : 'z';
    ori[slot] = axis === positionAxis ? 0 : 1;
  }
  return { perm, ori };
}

// ---- Комбинаторное кодирование (для построения компактных координат) ----

/** Lehmer code -> индекс перестановки длины n (0..n!-1) */
export function permutationToIndex(perm) {
  const n = perm.length;
  const fact = new Array(n + 1).fill(1);
  for (let i = 1; i <= n; i++) fact[i] = fact[i - 1] * i;

  let index = 0;
  for (let i = 0; i < n; i++) {
    let smaller = 0;
    for (let j = i + 1; j < n; j++) if (perm[j] < perm[i]) smaller++;
    index += smaller * fact[n - 1 - i];
  }
  return index;
}

/** индекс перестановки -> массив длины n (обратно permutationToIndex) */
export function indexToPermutation(index, n) {
  const fact = new Array(n + 1).fill(1);
  for (let i = 1; i <= n; i++) fact[i] = fact[i - 1] * i;

  const available = Array.from({ length: n }, (_, i) => i);
  const perm = new Array(n);
  let idx = index;
  for (let i = 0; i < n; i++) {
    const f = fact[n - 1 - i];
    const pos = Math.floor(idx / f);
    idx %= f;
    perm[i] = available[pos];
    available.splice(pos, 1);
  }
  return perm;
}

/** ориентации (base-значная система, длина count, последняя цифра зависима) -> индекс */
export function orientationToIndex(ori, base, count) {
  let index = 0;
  for (let i = 0; i < count - 1; i++) index = index * base + ori[i];
  return index;
}

/** индекс -> массив ориентаций длины count (последняя цифра восстанавливается по сумме % base == 0) */
export function indexToOrientation(index, base, count) {
  const ori = new Array(count).fill(0);
  let idx = index;
  let sum = 0;
  for (let i = count - 2; i >= 0; i--) {
    ori[i] = idx % base;
    idx = Math.floor(idx / base);
    sum += ori[i];
  }
  ori[count - 1] = ((base - (sum % base)) % base);
  return ori;
}

/** индекс сочетания (какие k из n позиций отмечены) -> число 0..C(n,k)-1.
 * marked: array длины n из 0/1 (ровно k единиц). Использует стандартную
 * комбинаторную систему счисления: для отсортированных по возрастанию
 * позиций p_0 < p_1 < ... < p_(k-1), index = sum C(p_i, i+1).
 * Проверено полным перебором всех C(12,4)=495 комбинаций (round-trip). */
export function combinationToIndex(marked, k) {
  const positions = [];
  for (let i = 0; i < marked.length; i++) if (marked[i]) positions.push(i);
  let index = 0;
  for (let i = 0; i < k; i++) index += binomial(positions[i], i + 1);
  return index;
}

export function indexToCombination(index, n, k) {
  const marked = new Array(n).fill(0);
  let idx = index;
  for (let i = k; i >= 1; i--) {
    let p = i - 1;
    while (binomial(p + 1, i) <= idx) p++;
    marked[p] = 1;
    idx -= binomial(p, i);
  }
  return marked;
}

const binomialCache = new Map();
export function binomial(n, k) {
  if (k < 0 || k > n) return 0;
  if (k === 0 || k === n) return 1;
  const key = n + ',' + k;
  if (binomialCache.has(key)) return binomialCache.get(key);
  const val = binomial(n - 1, k - 1) + binomial(n - 1, k);
  binomialCache.set(key, val);
  return val;
}

// ---- Итоговые координаты Коциембы, вычисляемые прямо из кубика ----

/**
 * Все координаты, нужные для фазы 1 и фазы 2.
 */
export function computeAllCoordinates(cube) {
  const { perm: cornerPerm, ori: twist } = readCorners(cube);
  const { perm: edgePerm, ori: flip } = readEdges(cube);

  const twistIndex = orientationToIndex(twist, 3, 8);
  const flipIndex = orientationToIndex(flip, 2, 12);

  // UDSlice (фаза 1): какие из 12 позиций сейчас заняты "экваториальными" фигурами (id 8..11)
  const sliceMarked = edgePerm.map((identity) => (identity >= SLICE_EDGE_START ? 1 : 0));
  const udSliceIndex = combinationToIndex(sliceMarked, 4);

  // Для фазы 2 (валидны только когда udSliceIndex === 0, т.е. слайс-рёбра уже в позициях 8..11):
  const cornerPermIndex = permutationToIndex(cornerPerm);
  const edgePerm8 = edgePerm.slice(0, 8); // перестановка идентичностей 0..7 среди позиций 0..7
  const edgePerm8Index = permutationToIndex(edgePerm8);
  const slicePerm4 = edgePerm.slice(8, 12).map((id) => id - SLICE_EDGE_START); // 0..3 среди позиций 8..11
  const slicePermIndex = permutationToIndex(slicePerm4);

  return {
    twist: twistIndex,
    flip: flipIndex,
    udSlice: udSliceIndex,
    cornerPerm: cornerPermIndex,
    edgePerm8: edgePerm8Index,
    slicePerm: slicePermIndex,
  };
}
