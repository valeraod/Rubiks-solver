// idastar.js
// Универсальный IDA* поиск поверх координат (не кубика напрямую) — использует
// move-таблицы и pruning-таблицы для быстрых переходов и оценки снизу.

/**
 * Каноническая отсечка "не делать бессмысленно коммутирующие ходы в обоих
 * порядках": для каждой оси (U/D, L/R, F/B) разрешаем ходы по обеим граням
 * подряд только в одном фиксированном порядке (напр. после D нельзя U, но
 * после U можно D) — это не теряет решений (U D и D U коммутируют, дают тот
 * же результат для непересекающихся по времени ходов), но вдвое сокращает
 * ветвление на таких парах. Повтор одной и той же грани подряд запрещён
 * полностью (эквивалентно уже покрыто ходом-удвоением, напр. U2).
 */
function makeSameAxisPrune(moveTokens) {
  const AXIS = { U: 'UD', D: 'UD', L: 'LR', R: 'LR', F: 'FB', B: 'FB' };
  const PRIORITY = { U: 0, D: 1, L: 0, R: 1, F: 0, B: 1 };
  const faceOf = (mi) => moveTokens[mi][0];

  return (lastMoveIndex, mi) => {
    if (lastMoveIndex === null) return false;
    const lastFace = faceOf(lastMoveIndex);
    const face = faceOf(mi);
    if (face === lastFace) return true;
    if (AXIS[face] === AXIS[lastFace] && PRIORITY[face] < PRIORITY[lastFace]) return true;
    return false;
  };
}

/**
 * @param {object} opts
 * @param {*} opts.initial - начальное состояние (любая структура)
 * @param {(state:*) => number} opts.heuristic - допустимая оценка снизу (0 = цель)
 * @param {(state:*, moveIndex:number) => *} opts.applyMove
 * @param {number} opts.movesCount
 * @param {string[]} opts.moveTokens - для отсечки одинаковой оси/грани
 * @param {number} [opts.maxBound=25]
 * @returns {number[]|null} последовательность индексов ходов, или null если не найдено в пределах maxBound
 */
export function idaStar({ initial, heuristic, applyMove, movesCount, moveTokens, maxBound = 25 }) {
  const samePrune = makeSameAxisPrune(moveTokens);
  let bound = heuristic(initial);
  if (bound === 0) return [];
  const path = [];

  function search(node, g, bound) {
    const h = heuristic(node);
    const f = g + h;
    if (f > bound) return f;
    if (h === 0) return -1; // FOUND (используем -1 как сигнал, т.к. это не валидная граница)
    let min = Infinity;
    const lastMoveIndex = path.length > 0 ? path[path.length - 1] : null;
    for (let mi = 0; mi < movesCount; mi++) {
      if (samePrune(lastMoveIndex, mi)) continue;
      const next = applyMove(node, mi);
      path.push(mi);
      const t = search(next, g + 1, bound);
      if (t === -1) return -1;
      if (t < min) min = t;
      path.pop();
    }
    return min;
  }

  while (bound <= maxBound) {
    const t = search(initial, 0, bound);
    if (t === -1) return path.slice();
    if (t === Infinity) return null;
    bound = t;
  }
  return null;
}
