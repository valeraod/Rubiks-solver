import test from 'node:test';
import assert from 'node:assert/strict';
import * as E from '../js/engine.js';
import {
  NetEditor, cloneFacelets, nextLabel, rotateGridCW, rotateGridTimes,
} from '../js/netEditor.js';

function solvedFacelets() {
  return E.getAllFacelets(E.newSolvedCube());
}

test('nextLabel: цикл по кругу U→R→F→D→L→B→U, поддерживает отрицательный шаг', () => {
  assert.equal(nextLabel('U'), 'R');
  assert.equal(nextLabel('B'), 'U');
  assert.equal(nextLabel('U', -1), 'B');
  assert.equal(nextLabel('R', -1), 'U');
});

test('nextLabel: полный цикл из 6 шагов возвращает исходную метку', () => {
  let label = 'F';
  for (let i = 0; i < 6; i++) label = nextLabel(label);
  assert.equal(label, 'F');
});

test('rotateGridCW: поворачивает сетку 3x3 по часовой стрелке, центр неподвижен', () => {
  const grid = [0, 1, 2, 3, 4, 5, 6, 7, 8];
  assert.deepEqual(rotateGridCW(grid), [6, 3, 0, 7, 4, 1, 8, 5, 2]);
  assert.equal(rotateGridCW(grid)[4], grid[4]);
});

test('rotateGridTimes: 4 поворота по часовой = тождество, поддерживает отрицательные значения', () => {
  const grid = [0, 1, 2, 3, 4, 5, 6, 7, 8];
  assert.deepEqual(rotateGridTimes(grid, 4), grid);
  assert.deepEqual(rotateGridTimes(grid, 0), grid);
  assert.deepEqual(rotateGridTimes(grid, -1), rotateGridTimes(grid, 3));
  assert.deepEqual(rotateGridTimes(grid, 1), rotateGridCW(grid));
});

test('cloneFacelets: глубокая копия по граням — мутация клона не трогает оригинал', () => {
  const f = solvedFacelets();
  const clone = cloneFacelets(f);
  clone.U[0] = 'ZZZ';
  assert.equal(f.U[0], 'U');
});

test('NetEditor: начальное состояние — клон переданных facelets, валиден', () => {
  const f = solvedFacelets();
  const editor = new NetEditor(f);
  assert.deepEqual(editor.facelets, f);
  assert.equal(editor.validation.valid, true);
  for (const face of E.FACES) assert.equal(editor.counts[face], 9);
});

test('NetEditor: cycleSticker меняет один цвет по кругу и не мутирует исходный объект конструктора', () => {
  const f = solvedFacelets();
  const editor = new NetEditor(f);
  editor.cycleSticker('U', 0);
  assert.equal(editor.facelets.U[0], 'R');
  assert.equal(f.U[0], 'U', 'исходный facelets, переданный в конструктор, не должен измениться');

  editor.cycleSticker('U', 0); // ещё раз тем же клетком
  assert.equal(editor.facelets.U[0], 'F');

  editor.cycleSticker('U', 0, -1); // назад
  assert.equal(editor.facelets.U[0], 'R');
});

test('NetEditor: cycleSticker бросает ошибку на центре (индекс 4)', () => {
  const editor = new NetEditor(solvedFacelets());
  assert.throws(() => editor.cycleSticker('U', 4), /центр грани/);
});

test('NetEditor: setSticker ставит цвет напрямую, проверяет индекс центра и допустимость метки', () => {
  const editor = new NetEditor(solvedFacelets());
  editor.setSticker('U', 0, 'B');
  assert.equal(editor.facelets.U[0], 'B');
  assert.throws(() => editor.setSticker('U', 4, 'B'), /центр грани/);
  assert.throws(() => editor.setSticker('U', 0, 'ZZ'), /неизвестная метка/);
});

test('NetEditor: rotateFace поворачивает грань как блок, не трогая остальные', () => {
  const f = solvedFacelets();
  f.U = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i'];
  const editor = new NetEditor(f);
  editor.rotateFace('U', 1);
  assert.deepEqual(editor.facelets.U, rotateGridCW(f.U));
  assert.deepEqual(editor.facelets.R, f.R); // другие грани не тронуты

  editor.rotateFace('U', 3); // ещё 3 раза = назад к исходному состоянию (в сумме 4)
  assert.deepEqual(editor.facelets.U, f.U);
});

test('NetEditor: живая валидация отражает текущее состояние после мутаций', () => {
  const editor = new NetEditor(solvedFacelets());
  assert.equal(editor.validation.valid, true);

  editor.cycleSticker('U', 0); // U:8, R:10 → WRONG_COLOR_COUNT
  assert.equal(editor.validation.valid, false);
  assert.equal(editor.validation.errors[0].code, 'WRONG_COLOR_COUNT');

  editor.cycleSticker('U', 0, -1); // вернули как было
  assert.equal(editor.validation.valid, true);
});

test('NetEditor: reset заменяет состояние целиком и не делится массивами со старым состоянием', () => {
  const editor = new NetEditor(solvedFacelets());
  editor.cycleSticker('U', 0);
  const fresh = solvedFacelets();
  editor.reset(fresh);
  assert.deepEqual(editor.facelets, fresh);
  editor.cycleSticker('U', 0);
  assert.equal(fresh.U[0], 'U', 'reset должен клонировать, а не сохранять ссылку');
});

test('интеграция: NetEditor на реальном скрамбле остаётся валидным и решаемым (validation.cube)', () => {
  const cube = E.newSolvedCube();
  E.applyMoves(cube, ['R', "U'", 'F2', "L'", 'D', "B'"]);
  const editor = new NetEditor(E.getAllFacelets(cube));
  const result = editor.validation;
  assert.equal(result.valid, true);
  assert.deepEqual(E.getAllFacelets(result.cube), E.getAllFacelets(cube));
});
