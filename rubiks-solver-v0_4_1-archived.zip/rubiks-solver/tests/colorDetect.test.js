import test from 'node:test';
import assert from 'node:assert/strict';
import * as E from '../js/engine.js';
import {
  toImageData, averageColorAt, sampleFaceGrid, rgbToLab, detectCubeColors,
} from '../js/colorDetect.js';

// "Реальные" цвета наклеек кубика — намеренно включают красный/оранжевый,
// самую сложную пару для различения (близки в RGB, дальше в Lab).
const STICKER_RGB = {
  U: { r: 255, g: 255, b: 255 }, // белый
  R: { r: 196, g: 30, b: 40 },   // красный
  F: { r: 0, g: 140, b: 70 },    // зелёный
  D: { r: 255, g: 213, b: 0 },   // жёлтый
  L: { r: 255, g: 110, b: 20 },  // оранжевый
  B: { r: 20, g: 70, b: 180 },   // синий
};

const CELL_PX = 30; // размер одной ячейки сетки 3x3 в синтетическом изображении

// Строит ImageData-подобный объект { width, height, data } размером
// (3*CELL_PX) x (3*CELL_PX), где ячейка (r,c) закрашена цветом colors[r*3+c]
// (с опциональным аддитивным шумом на каждый пиксель — для проверки
// устойчивости сэмплинга).
function makeFaceImage(colors, noise = 0) {
  const size = CELL_PX * 3;
  const data = new Uint8ClampedArray(size * size * 4);
  for (let y = 0; y < size; y++) {
    const r = Math.floor(y / CELL_PX);
    for (let x = 0; x < size; x++) {
      const c = Math.floor(x / CELL_PX);
      const base = colors[r * 3 + c];
      const i = (y * size + x) * 4;
      const jitter = () => (noise ? (Math.random() * 2 - 1) * noise : 0);
      data[i] = base.r + jitter();
      data[i + 1] = base.g + jitter();
      data[i + 2] = base.b + jitter();
      data[i + 3] = 255;
    }
  }
  return { width: size, height: size, data };
}

// Строит все 6 изображений кубика из facelets ({U:[9 home-букв],...}, как
// возвращает engine.js#getAllFacelets) через таблицу STICKER_RGB.
function makeCubeImages(facelets, noise = 0) {
  const out = {};
  for (const f of E.FACES) {
    out[f] = makeFaceImage(facelets[f].map((label) => STICKER_RGB[label]), noise);
  }
  return out;
}

test('averageColorAt: усредняет площадку и обрезается по границам изображения', () => {
  const img = makeFaceImage(new Array(9).fill(STICKER_RGB.R));
  const c = averageColorAt(img, 0, 0, 4); // угол изображения — часть окна выходит за границу
  assert.equal(Math.round(c.r), STICKER_RGB.R.r);
  assert.equal(Math.round(c.g), STICKER_RGB.R.g);
  assert.equal(Math.round(c.b), STICKER_RGB.R.b);
});

test('sampleFaceGrid: возвращает 9 цветов в row-major порядке, совпадающем с исходной раскладкой', () => {
  const colors = E.FACES.map((f) => STICKER_RGB[f]); // 6 разных цветов, но нам нужно 9 — переиспользуем с разными гранями
  const nineColors = [
    STICKER_RGB.U, STICKER_RGB.R, STICKER_RGB.F,
    STICKER_RGB.D, STICKER_RGB.L, STICKER_RGB.B,
    STICKER_RGB.U, STICKER_RGB.R, STICKER_RGB.F,
  ];
  const img = makeFaceImage(nineColors);
  const grid = sampleFaceGrid(img);
  assert.equal(grid.length, 9);
  for (let i = 0; i < 9; i++) {
    assert.equal(Math.round(grid[i].r), nineColors[i].r, `cell ${i} r`);
    assert.equal(Math.round(grid[i].g), nineColors[i].g, `cell ${i} g`);
    assert.equal(Math.round(grid[i].b), nineColors[i].b, `cell ${i} b`);
  }
  void colors; // (не используется, оставлено для наглядности набора цветов)
});

test('rgbToLab: известные опорные значения (белый/чёрный) в разумных пределах', () => {
  const white = rgbToLab({ r: 255, g: 255, b: 255 });
  assert.ok(Math.abs(white.L - 100) < 1, 'L белого ~100');
  assert.ok(Math.abs(white.a) < 1 && Math.abs(white.b) < 1, 'a,b белого ~0');

  const black = rgbToLab({ r: 0, g: 0, b: 0 });
  assert.ok(Math.abs(black.L) < 1, 'L чёрного ~0');
});

test('toImageData: принимает готовый ImageData-подобный объект без изменений', () => {
  const img = makeFaceImage(new Array(9).fill(STICKER_RGB.U));
  assert.equal(toImageData(img), img);
});

test('toImageData: принимает canvas-подобный объект через getContext("2d").getImageData()', () => {
  const img = makeFaceImage(new Array(9).fill(STICKER_RGB.F));
  const fakeCanvas = {
    width: img.width,
    height: img.height,
    getContext(kind) {
      assert.equal(kind, '2d');
      return { getImageData: () => img };
    },
  };
  assert.equal(toImageData(fakeCanvas), img);
});

test('toImageData: бросает ошибку на неподдерживаемом источнике', () => {
  assert.throws(() => toImageData({}), /неподдерживаемый источник/);
});

test('detectCubeColors: собранный кубик — все метки верны, уверенность максимальна', () => {
  const cube = E.newSolvedCube();
  const facelets = E.getAllFacelets(cube);
  const images = makeCubeImages(facelets);
  const { facelets: detected, confidence } = detectCubeColors(images);
  for (const f of E.FACES) {
    assert.deepEqual(detected[f], facelets[f], `грань ${f}`);
    for (const conf of confidence[f]) assert.ok(conf > 0.99, `уверенность на грани ${f}: ${conf}`);
  }
});

test('detectCubeColors: распознаёт случайно перемешанный кубик и решатель принимает результат', () => {
  const MOVESET = [];
  for (const f of ['U', 'D', 'L', 'R', 'F', 'B']) for (const m of ['', "'", '2']) MOVESET.push(f + m);
  const cube = E.newSolvedCube();
  const scramble = [];
  for (let i = 0; i < 25; i++) scramble.push(MOVESET[Math.floor(Math.random() * MOVESET.length)]);
  E.applyMoves(cube, scramble);

  const expectedFacelets = E.getAllFacelets(cube);
  const images = makeCubeImages(expectedFacelets);
  const { facelets: detected } = detectCubeColors(images);

  for (const f of E.FACES) assert.deepEqual(detected[f], expectedFacelets[f], `грань ${f}`);

  // распознанные facelets должны собираться обратно в тот же кубик через engine.js
  const rebuilt = E.cubeFromFacelets(detected);
  assert.deepEqual(E.getAllFacelets(rebuilt), expectedFacelets);
});

test('detectCubeColors: устойчиво к шуму сенсора (усреднение по площадке компенсирует джиттер)', () => {
  const cube = E.newSolvedCube();
  E.applyMoves(cube, ["R", "U", "F'", "L2", "D", "B'", "U2", "R'"]);
  const expectedFacelets = E.getAllFacelets(cube);
  const images = makeCubeImages(expectedFacelets, /* noise */ 12);
  const { facelets: detected } = detectCubeColors(images);
  for (const f of E.FACES) assert.deepEqual(detected[f], expectedFacelets[f], `грань ${f}`);
});

test('detectCubeColors: низкая уверенность на границе между двумя цветами, высокая — на чистом цвете', () => {
  const cube = E.newSolvedCube();
  const facelets = E.getAllFacelets(cube);
  const images = makeCubeImages(facelets);

  // Портим один пиксель грани R (наклейку с индексом 0) так, чтобы она легла
  // ровно посередине между red и orange по RGB (грубая имитация неоднозначной наклейки).
  const mid = {
    r: (STICKER_RGB.R.r + STICKER_RGB.L.r) / 2,
    g: (STICKER_RGB.R.g + STICKER_RGB.L.g) / 2,
    b: (STICKER_RGB.R.b + STICKER_RGB.L.b) / 2,
  };
  const { width, data } = images.R;
  for (let y = 0; y < CELL_PX; y++) {
    for (let x = 0; x < CELL_PX; x++) {
      const i = (y * width + x) * 4;
      data[i] = mid.r; data[i + 1] = mid.g; data[i + 2] = mid.b;
    }
  }

  const { confidence } = detectCubeColors(images);
  assert.ok(confidence.R[0] < 0.2, `амбигуальная наклейка должна иметь низкую уверенность, получили ${confidence.R[0]}`);
  assert.ok(confidence.R[4] > 0.99, 'неизменный центр остаётся уверенным эталоном');
});

test('detectCubeColors: бросает понятную ошибку, если не хватает изображения грани', () => {
  const cube = E.newSolvedCube();
  const facelets = E.getAllFacelets(cube);
  const images = makeCubeImages(facelets);
  delete images.B;
  assert.throws(() => detectCubeColors(images), /отсутствует изображение грани B/);
});

test('detectCubeColors: опция colorSpace="rgb" тоже работает и даёт корректный результат на чистых цветах', () => {
  const cube = E.newSolvedCube();
  E.applyMoves(cube, ['R', "U'", 'F2']);
  const expectedFacelets = E.getAllFacelets(cube);
  const images = makeCubeImages(expectedFacelets);
  const { facelets: detected } = detectCubeColors(images, { colorSpace: 'rgb' });
  for (const f of E.FACES) assert.deepEqual(detected[f], expectedFacelets[f], `грань ${f}`);
});
