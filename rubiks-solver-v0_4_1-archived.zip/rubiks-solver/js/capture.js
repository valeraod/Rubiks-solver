// capture.js
// Мастер съёмки кубика: 2 хвата, 6 кадров (см. HANDOFF.md §3.3).
//
// Разделён на два слоя намеренно:
// - "ядро" (CAPTURE_STEPS, defaultGridRect, extractGridImageData,
//   isGridRectValid, CaptureWizard) — чистые функции и класс без обращений
//   к DOM/camera API, тестируется headless теми же синтетическими
//   ImageData, что и colorDetect.js;
// - "обвязка" (startCamera/stopCamera/grabFrameFromVideo/loadImageFile) —
//   тонкие браузерные адаптеры поверх getUserMedia/canvas/File, приводят
//   любой источник кадра к тому же ImageData-подобному объекту
//   { width, height, data }, который понимает ядро и colorDetect.js.
//
// Порядок протокола 1:1 соответствует буквам граней движка (engine.js
// FACES): Front=F, Top=U, Back=B, Bottom=D (первый хват, 3 поворота кубика
// вокруг одной горизонтальной оси в одну сторону), затем перехват и
// Right=R, Left=L (второй хват, поворот на 180°). Направление первых трёх
// поворотов не задаётся жёстко словами вроде "на себя/от себя" — на практике
// это оказалось неоднозначным (зависит от того, как держат телефон), поэтому
// инструкция описывает результат ("верхняя грань — к камере") и даёт
// самопроверку направления, а не конкретный жест. Итоговый результат мастера
// (finish()) — объект { U,R,F,D,L,B: ImageData }, который можно передать
// прямо в colorDetect.js#detectCubeColors() без какой-либо дополнительной сборки.

// ---- протокол съёмки ----

export const CAPTURE_STEPS = [
  {
    face: 'F',
    grip: 'A',
    title: 'Кадр 1 из 6 — передняя грань',
    instruction: 'Держите кубик как обычно, передней гранью к камере.',
    rotateFromPrev: null,
  },
  {
    face: 'U',
    grip: 'A',
    title: 'Кадр 2 из 6 — верхняя грань',
    instruction: 'Поверните кубик на 90° вокруг горизонтальной оси (слева направо) — так, чтобы к камере оказалась обращена грань, которая только что смотрела вверх.',
    rotateFromPrev: { axis: 'x', deg: 90 },
    warn: 'Если вместо неё к камере повернулась нижняя грань — вы крутите в обратную сторону: доверните ещё на 180° и продолжайте уже в эту сторону.',
  },
  {
    face: 'B',
    grip: 'A',
    title: 'Кадр 3 из 6 — задняя грань',
    instruction: 'Ещё раз поверните на 90° вокруг той же оси, в ту же сторону, что и на прошлом шаге.',
    rotateFromPrev: { axis: 'x', deg: 90 },
  },
  {
    face: 'D',
    grip: 'A',
    title: 'Кадр 4 из 6 — нижняя грань',
    instruction: 'Ещё раз поверните на 90° в ту же сторону.',
    rotateFromPrev: { axis: 'x', deg: 90 },
    warn: 'Частая ошибка — сбиться со счёта поворотов. Проверка: ещё один такой же поворот должен вернуть переднюю грань (кадр 1).',
  },
  {
    face: 'R',
    grip: 'B',
    title: 'Кадр 5 из 6 — правая грань',
    instruction: 'Перехватите кубик другим хватом, открыв боковые грани, и сфотографируйте правую.',
    rotateFromPrev: null,
    regrip: true,
  },
  {
    face: 'L',
    grip: 'B',
    title: 'Кадр 6 из 6 — левая грань',
    instruction: 'Поверните кубик на 180° вокруг вертикальной оси, как дверную ручку.',
    rotateFromPrev: { axis: 'y', deg: 180 },
  },
];

// ---- работа с прямоугольником сетки-гида ----

// Квадратная сетка по умолчанию: 60% меньшей стороны кадра, по центру.
export function defaultGridRect(width, height) {
  const size = Math.max(1, Math.round(Math.min(width, height) * 0.6));
  return {
    x: Math.round((width - size) / 2),
    y: Math.round((height - size) / 2),
    size,
  };
}

// Сетка обязана целиком помещаться в кадр — иначе часть наклеек будет
// вырезана мимо изображения и colorDetect получит мусор вместо цвета.
export function isGridRectValid(width, height, gridRect) {
  const { x, y, size } = gridRect;
  return size > 0 && x >= 0 && y >= 0 && x + size <= width && y + size <= height;
}

// Копирует квадратную область gridRect из sourceImageData в новый
// ImageData-подобный объект { width: size, height: size, data }. Не
// масштабирует и не усредняет — просто вырезка; усреднение по ячейкам сетки
// 3x3 делает colorDetect.js#sampleFaceGrid на выходе этой функции.
export function extractGridImageData(sourceImageData, gridRect) {
  const { width: sw, height: sh, data: sdata } = sourceImageData;
  if (!isGridRectValid(sw, sh, gridRect)) {
    throw new Error('extractGridImageData: сетка выходит за границы кадра');
  }
  const { x: gx, y: gy, size } = gridRect;
  const out = new Uint8ClampedArray(size * size * 4);
  for (let y = 0; y < size; y++) {
    const srcRowStart = ((gy + y) * sw + gx) * 4;
    const dstRowStart = (y * size) * 4;
    out.set(sdata.subarray(srcRowStart, srcRowStart + size * 4), dstRowStart);
  }
  return { width: size, height: size, data: out };
}

// ---- мастер: пошаговая стейт-машина по 6 кадрам ----

export class CaptureWizard {
  constructor() {
    this.stepIndex = 0;
    this.captured = {}; // face -> ImageData-подобный объект (уже вырезанный по сетке)
  }

  get step() {
    return CAPTURE_STEPS[this.stepIndex];
  }

  get isLastStep() {
    return this.stepIndex === CAPTURE_STEPS.length - 1;
  }

  get progress() {
    return { current: this.stepIndex + 1, total: CAPTURE_STEPS.length };
  }

  hasCurrent() {
    return !!this.captured[this.step.face];
  }

  isComplete() {
    return CAPTURE_STEPS.every((s) => !!this.captured[s.face]);
  }

  // sourceImageData — полный кадр (с камеры или из файла); gridRect — текущее
  // положение сетки-гида поверх него (по умолчанию — центрированный квадрат).
  // Возвращает вырезанный по сетке кадр (тот же объект сохраняется как
  // текущий снимок этой грани).
  captureCurrent(sourceImageData, gridRect) {
    const rect = gridRect || defaultGridRect(sourceImageData.width, sourceImageData.height);
    const cropped = extractGridImageData(sourceImageData, rect);
    this.captured[this.step.face] = cropped;
    return cropped;
  }

  retakeCurrent() {
    delete this.captured[this.step.face];
  }

  next() {
    if (!this.hasCurrent()) throw new Error('next: текущий кадр ещё не снят');
    if (this.isLastStep) throw new Error('next: это последний кадр, используйте finish()');
    this.stepIndex++;
  }

  back() {
    if (this.stepIndex === 0) throw new Error('back: уже на первом кадре');
    this.stepIndex--;
  }

  // Прыжок на произвольный шаг (например, по клику на индикатор прогресса)
  // — можно вернуться и переснять уже отснятый кадр, не проходя мастер заново.
  goToStep(index) {
    if (index < 0 || index >= CAPTURE_STEPS.length) {
      throw new Error('goToStep: индекс шага вне диапазона 0..' + (CAPTURE_STEPS.length - 1));
    }
    this.stepIndex = index;
  }

  // Возвращает { U,R,F,D,L,B: ImageData } — готово для
  // colorDetect.js#detectCubeColors(). Бросает ошибку, если сняты не все 6.
  finish() {
    if (!this.isComplete()) {
      const missing = CAPTURE_STEPS.filter((s) => !this.captured[s.face]).map((s) => s.face);
      throw new Error('finish: не все кадры сняты, не хватает: ' + missing.join(', '));
    }
    const facesImages = {};
    for (const s of CAPTURE_STEPS) facesImages[s.face] = this.captured[s.face];
    return facesImages;
  }
}

// ---- браузерные адаптеры (не тестируются headless, требуют DOM) ----

// Открывает камеру на переданном <video>, возвращает MediaStream (его же
// нужно передать в stopCamera при закрытии). facingMode: 'environment' —
// мягкое пожелание ("задняя камера, если она есть"): это ideal-constraint,
// а не exact, поэтому на устройствах без задней камеры (веб-камера на
// десктопе, фронталка) браузер его просто игнорирует и подключает то, что
// есть — вызов не падает и не требует отдельной ветки под тип устройства.
export async function startCamera(videoEl, constraints = { video: { facingMode: 'environment' } }) {
  if (!(typeof navigator !== 'undefined' && navigator.mediaDevices && navigator.mediaDevices.getUserMedia)) {
    throw new Error('startCamera: getUserMedia недоступен в этом окружении');
  }
  const stream = await navigator.mediaDevices.getUserMedia(constraints);
  videoEl.srcObject = stream;
  await videoEl.play();
  return stream;
}

export function stopCamera(stream) {
  if (stream) for (const track of stream.getTracks()) track.stop();
}

// Снимает текущий кадр видео в offscreen-canvas и возвращает ImageData.
export function grabFrameFromVideo(videoEl) {
  const canvas = document.createElement('canvas');
  canvas.width = videoEl.videoWidth;
  canvas.height = videoEl.videoHeight;
  const ctx = canvas.getContext('2d');
  ctx.drawImage(videoEl, 0, 0);
  return ctx.getImageData(0, 0, canvas.width, canvas.height);
}

// Загружает выбранный пользователем файл (File/Blob) как ImageData —
// альтернативный источник кадра вместо камеры (тот же мастер, тот же формат).
export async function loadImageFile(file) {
  const bitmap = await createImageBitmap(file);
  const canvas = document.createElement('canvas');
  canvas.width = bitmap.width;
  canvas.height = bitmap.height;
  const ctx = canvas.getContext('2d');
  ctx.drawImage(bitmap, 0, 0);
  return ctx.getImageData(0, 0, canvas.width, canvas.height);
}
