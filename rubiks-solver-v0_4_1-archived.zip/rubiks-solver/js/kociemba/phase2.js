// phase2.js
// Фаза 2: внутри подгруппы G1 дособрать кубик полностью, используя только
// ходы {U,U',U2,D,D',D2,L2,R2,F2,B2} (не выводящие из G1).

import { idaStar } from './idastar.js';

/**
 * @param {{cornerPerm:number, edgePerm8:number, slicePerm:number}} start
 * @param {object} tables - результат loadTables()
 * @param {number} [maxBound]
 * @returns {string[]|null}
 */
export function solvePhase2(start, tables, maxBound = 18) {
  const { phase2Moves } = tables.meta;
  const movesCount = phase2Moves.length;

  const heuristic = ({ cornerPerm, edgePerm8, slicePerm }) => Math.max(
    tables.prunCornerSlice[cornerPerm * 24 + slicePerm],
    tables.prunEdge8Slice[edgePerm8 * 24 + slicePerm],
  );

  const applyMove = ({ cornerPerm, edgePerm8, slicePerm }, mi) => ({
    cornerPerm: tables.cornerPermMove[cornerPerm * movesCount + mi],
    edgePerm8: tables.edgePerm8Move[edgePerm8 * movesCount + mi],
    slicePerm: tables.slicePermMove[slicePerm * movesCount + mi],
  });

  const initial = { cornerPerm: start.cornerPerm, edgePerm8: start.edgePerm8, slicePerm: start.slicePerm };

  const moveIndices = idaStar({
    initial,
    heuristic,
    applyMove,
    movesCount,
    moveTokens: phase2Moves,
    maxBound,
  });

  if (!moveIndices) return null;
  return moveIndices.map((mi) => phase2Moves[mi]);
}
