// phase1.js
// Фаза 1: довести кубик до подгруппы G1 = <U,D,L2,R2,F2,B2> — то есть все
// углы и рёбра сориентированы (twist=0, flip=0), а 4 экваториальных ребра
// стоят где-то в среднем слое (udSlice = SOLVED_UD_SLICE), порядок между
// ними неважен (это дособерёт фаза 2).

import { idaStar } from './idastar.js';
import { SOLVED_UD_SLICE } from './coordinates.js';

/**
 * @param {{twist:number, flip:number, udSlice:number}} start
 * @param {object} tables - результат loadTables()
 * @param {number} [maxBound]
 * @returns {string[]|null} последовательность ходов (токены из tables.meta.allMoves) или null
 */
export function solvePhase1(start, tables, maxBound = 12) {
  const { allMoves } = tables.meta;
  const movesCount = allMoves.length;

  const heuristic = ({ twist, flip, udSlice }) => Math.max(
    tables.prunTwistSlice[twist * 495 + udSlice],
    tables.prunFlipSlice[flip * 495 + udSlice],
  );

  const applyMove = ({ twist, flip, udSlice }, mi) => ({
    twist: tables.twistMove[twist * movesCount + mi],
    flip: tables.flipMove[flip * movesCount + mi],
    udSlice: tables.udSliceMove[udSlice * movesCount + mi],
  });

  const initial = { twist: start.twist, flip: start.flip, udSlice: start.udSlice };

  const moveIndices = idaStar({
    initial,
    heuristic,
    applyMove,
    movesCount,
    moveTokens: allMoves,
    maxBound,
  });

  if (!moveIndices) return null;
  return moveIndices.map((mi) => allMoves[mi]);
}

export { SOLVED_UD_SLICE };
