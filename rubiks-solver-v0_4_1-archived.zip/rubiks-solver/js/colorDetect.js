// colorDetect.js
// Распознавание цвета наклеек кубика по фотографиям граней.
//
// Не полагаемся на фиксированные "стандартные" цвета кубика (кубик может
// быть с нестандартной раскраской, см. HANDOFF.md §3.4). Эталон каждого из
// 6 цветов — центральная наклейка соответствующей грани: центры физически
// не двигаются при поворотах, поэтому их цвет однозначно задаёт "домашний"
// цвет всей грани. Каждая из 48 остальных наклеек относится к ближайшему из
// 6 эталонов (по умолчанию — расстояние в CIE Lab, устойчивее к освещению и
// лучше отличает близкие цвета вроде красного/оранжевого, чем RGB).
//
// Вход — по одному изображению на грань, в виде объекта, совместимого с
// CanvasRenderingContext2D#getImageData() ({ width, height, data }), где
// data — Uint8ClampedArray/Array RGBA по строкам (как ImageData в браузере),
// либо canvas-подобный объект с getContext('2d'). Ключи объекта — буквы
// граней (см. engine.js FACES: U,R,F,D,L,B) — тот же набор, что придёт из
// capture.js (этап 0.3.0) по протоколу съёмки.
//
// Выход — facelets в формате engine.js#cubeFromFacelets: для каждой грани
// массив из 9 меток в row-major порядке (см. engine.js initPos: индекс
// r*3+c, r/c — строка/столбец кадра сверху-вниз, слева-направо), где метка —
// буква грани, чей центр оказался ближе всего к данной наклейке.

import { FACES } from './engine.js';

const DEFAULT_SAMPLE_RADIUS = 4; // половина стороны квадрата усреднения, px
const DEFAULT_COLOR_SPACE = 'lab'; // 'lab' | 'rgb'

// ---- работа с изображением ----

// Приводит источник к объекту { width, height, data } (интерфейс ImageData).
// Принимает: уже готовый ImageData-подобный объект ({width,height,data}),
// либо (в браузере) canvas/OffscreenCanvas — тогда сам извлекает 2D-контекст
// и снимает getImageData() на весь кадр.
export function toImageData(source) {
  if (source && typeof source.width === 'number' && typeof source.height === 'number' && source.data) {
    return source;
  }
  if (source && typeof source.getContext === 'function') {
    const ctx = source.getContext('2d');
    return ctx.getImageData(0, 0, source.width, source.height);
  }
  throw new Error('toImageData: неподдерживаемый источник изображения (ожидался {width,height,data} или canvas)');
}

// Среднее RGB по квадрату (radius*2+1) x (radius*2+1) вокруг точки (cx,cy),
// с обрезкой по границам изображения. Усреднение по площадке, а не 1 пиксель
// — устойчивость к точечному шуму сенсора и бликам (HANDOFF.md §3.4).
export function averageColorAt(imageData, cx, cy, radius = DEFAULT_SAMPLE_RADIUS) {
  const { width, height, data } = imageData;
  const x0 = Math.max(0, Math.round(cx - radius));
  const x1 = Math.min(width - 1, Math.round(cx + radius));
  const y0 = Math.max(0, Math.round(cy - radius));
  const y1 = Math.min(height - 1, Math.round(cy + radius));
  let r = 0, g = 0, b = 0, n = 0;
  for (let y = y0; y <= y1; y++) {
    for (let x = x0; x <= x1; x++) {
      const i = (y * width + x) * 4;
      r += data[i]; g += data[i + 1]; b += data[i + 2];
      n++;
    }
  }
  if (n === 0) throw new Error('averageColorAt: пустая область сэмплинга (точка вне изображения?)');
  return { r: r / n, g: g / n, b: b / n };
}

// Координаты центра ячейки (row, col) сетки 3x3 на изображении width x height.
function cellCenter(width, height, row, col) {
  return {
    x: ((col + 0.5) * width) / 3,
    y: ((row + 0.5) * height) / 3,
  };
}

// Сэмплирует одну грань: возвращает массив из 9 { r, g, b } в row-major
// порядке (row=0 — верхняя строка кадра, col=0 — левый столбец), что
// соответствует порядку facelets[face][r*3+c] в engine.js#cubeFromFacelets.
export function sampleFaceGrid(imageDataSource, radius = DEFAULT_SAMPLE_RADIUS) {
  const imageData = toImageData(imageDataSource);
  const out = new Array(9);
  for (let r = 0; r < 3; r++) {
    for (let c = 0; c < 3; c++) {
      const { x, y } = cellCenter(imageData.width, imageData.height, r, c);
      out[r * 3 + c] = averageColorAt(imageData, x, y, radius);
    }
  }
  return out;
}

// ---- цветовые пространства и расстояние ----

function srgbToLinear(v) {
  const c = v / 255;
  return c <= 0.04045 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4);
}

// sRGB -> CIE Lab (D65). Более перцептивно равномерное пространство, чем
// RGB — важно для различения близких цветов кубика (красный/оранжевый).
export function rgbToLab({ r, g, b }) {
  const rl = srgbToLinear(r), gl = srgbToLinear(g), bl = srgbToLinear(b);
  const x = rl * 0.4124564 + gl * 0.3575761 + bl * 0.1804375;
  const y = rl * 0.2126729 + gl * 0.7151522 + bl * 0.0721750;
  const z = rl * 0.0193339 + gl * 0.1191920 + bl * 0.9503041;
  const Xn = 0.95047, Yn = 1.0, Zn = 1.08883;
  const f = (t) => (t > 0.008856 ? Math.cbrt(t) : 7.787 * t + 16 / 116);
  const fx = f(x / Xn), fy = f(y / Yn), fz = f(z / Zn);
  return { L: 116 * fy - 16, a: 500 * (fx - fy), b: 200 * (fy - fz) };
}

function distRgb(c1, c2) {
  const dr = c1.r - c2.r, dg = c1.g - c2.g, db = c1.b - c2.b;
  return Math.sqrt(dr * dr + dg * dg + db * db);
}

function distLab(c1, c2) {
  const dl = c1.L - c2.L, da = c1.a - c2.a, db = c1.b - c2.b;
  return Math.sqrt(dl * dl + da * da + db * db);
}

function colorDistance(c1, c2, space) {
  return space === 'rgb' ? distRgb(c1, c2) : distLab(rgbToLab(c1), rgbToLab(c2));
}

// ---- основной алгоритм: распознавание всего кубика ----

// facesImageData: { U: source, R: source, F: source, D: source, L: source, B: source }
// (все 6 ключей обязательны, см. engine.js FACES); source — что угодно,
// принимаемое toImageData().
//
// options:
// - colorSpace: 'lab' (по умолчанию) | 'rgb'
// - sampleRadius: половина стороны квадрата усреднения в px (по умолчанию 4)
//
// Возвращает { facelets, confidence }:
// - facelets — { U:[9 меток], ... } в формате engine.js#cubeFromFacelets;
// - confidence — { U:[9 чисел 0..1], ... } — эвристическая уверенность
//   каждой метки: 1 — наклейка однозначно ближе к "своему" эталону, чем к
//   следующему по близости; ближе к 0 — граница между двумя цветами.
//   Пригодится валидатору/редактору (0.4.0) для подсветки сомнительных клеток.
export function detectCubeColors(facesImageData, options = {}) {
  const space = options.colorSpace || DEFAULT_COLOR_SPACE;
  const radius = options.sampleRadius ?? DEFAULT_SAMPLE_RADIUS;

  for (const f of FACES) {
    if (!facesImageData[f]) throw new Error('detectCubeColors: отсутствует изображение грани ' + f);
  }

  const grids = {};
  for (const f of FACES) grids[f] = sampleFaceGrid(facesImageData[f], radius);

  // эталон каждого цвета — центральная наклейка (индекс 4 = r1,c1) своей грани
  const centers = {};
  for (const f of FACES) centers[f] = grids[f][4];

  const facelets = {};
  const confidence = {};
  for (const f of FACES) {
    facelets[f] = new Array(9);
    confidence[f] = new Array(9);
    for (let i = 0; i < 9; i++) {
      const sample = grids[f][i];
      const dists = FACES.map((cf) => ({ face: cf, d: colorDistance(sample, centers[cf], space) }));
      dists.sort((a, b) => a.d - b.d);
      const best = dists[0], second = dists[1];
      facelets[f][i] = best.face;
      confidence[f][i] = second.d > 0 ? Math.max(0, (second.d - best.d) / second.d) : 1;
    }
  }

  return { facelets, confidence };
}
