import test from 'node:test';
import assert from 'node:assert/strict';
import * as E from '../js/engine.js';

test('solved cube reports solved', () => {
  const cube = E.newSolvedCube();
  assert.equal(E.isSolved(cube), true);
});

test('each single move has order 4', () => {
  for (const f of ['U', 'D', 'L', 'R', 'F', 'B']) {
    const cube = E.newSolvedCube();
    for (let i = 0; i < 4; i++) E.applyMove(cube, f);
    assert.equal(E.isSolved(cube), true, `move ${f} order 4 failed`);
  }
});

test('(R U R\' U\') has order 6', () => {
  const cube = E.newSolvedCube();
  for (let i = 0; i < 6; i++) E.applyMoves(cube, ['R', 'U', "R'", "U'"]);
  assert.equal(E.isSolved(cube), true);
});

test('scramble followed by its exact inverse returns to solved (20 random trials)', () => {
  const moveset = [];
  for (const f of ['U', 'D', 'L', 'R', 'F', 'B']) for (const m of ['', "'", '2']) moveset.push(f + m);
  function randScramble(n) {
    const arr = [];
    for (let i = 0; i < n; i++) arr.push(moveset[Math.floor(Math.random() * moveset.length)]);
    return arr;
  }
  for (let t = 0; t < 20; t++) {
    const cube = E.newSolvedCube();
    const scr = randScramble(25);
    E.applyMoves(cube, scr);
    E.applyMoves(cube, E.inverseMoves(scr));
    assert.equal(E.isSolved(cube), true, 'failed for scramble ' + scr.join(' '));
  }
});

test('sune (R U R\' U R U2 R\') only affects U-layer corners: D face and all edges intact', () => {
  const cube = E.newSolvedCube();
  E.applyMoves(cube, ['R', 'U', "R'", 'U', 'R', 'U2', "R'"]);
  const g = E.getAllFacelets(cube);
  // D face fully untouched (whole bottom + middle layer intact)
  assert.equal(g.D.join(''), 'DDDDDDDDD');
  // U-layer edges (indices 1,3,5,7 in row-major grid) still show 'U'
  assert.equal(g.U[1], 'U');
  assert.equal(g.U[3], 'U');
  assert.equal(g.U[5], 'U');
  assert.equal(g.U[7], 'U');
});

test('cubeFromFacelets round-trips a solved cube', () => {
  const solved = E.newSolvedCube();
  const facelets = E.getAllFacelets(solved);
  const rebuilt = E.cubeFromFacelets(facelets);
  assert.equal(E.isSolved(rebuilt), true);
});

test('findEdge and findCorner locate pieces by color on a solved cube', () => {
  const cube = E.newSolvedCube();
  const edge = E.findEdge(cube, 'U', 'F');
  assert.equal(edge.length, 2);
  assert.deepEqual(edge.map((s) => s.home).sort(), ['F', 'U']);

  const corner = E.findCorner(cube, 'U', 'F', 'R');
  assert.equal(corner.length, 3);
  assert.deepEqual(corner.map((s) => s.home).sort(), ['F', 'R', 'U']);
});
