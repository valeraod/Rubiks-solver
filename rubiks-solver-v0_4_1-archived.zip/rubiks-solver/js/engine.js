// engine.js
// Универсальная 3D-модель кубика Рубика: 54 наклейки, каждая имеет
// фиксированный "home" (буква грани-источника: U/R/F/D/L/B — это и есть
// логический "цвет") и текущую позицию/направление, которые меняются
// поворотами граней.
//
// Формулы поворотов выведены геометрически (viewer смотрит на грань снаружи,
// "право" = "направление взгляда" x "вверх", правая система координат) и
// проверены тестами (см. tests/engine.test.js): порядок одиночного хода = 4,
// порядок (R U R' U') = 6, алгоритм sune трогает только верхние углы.

export const FACES = ['U', 'R', 'F', 'D', 'L', 'B'];

const NORMAL = {
  U: [0, 1, 0], D: [0, -1, 0], F: [0, 0, 1], B: [0, 0, -1], L: [-1, 0, 0], R: [1, 0, 0],
};

// начальная позиция наклейки по (грань, строка, столбец), r,c в 0..2
function initPos(face, r, c) {
  switch (face) {
    case 'U': return [c - 1, 1, r - 1];
    case 'D': return [c - 1, -1, 1 - r];
    case 'F': return [c - 1, 1 - r, 1];
    case 'B': return [1 - c, 1 - r, -1];
    case 'L': return [-1, 1 - r, c - 1];
    case 'R': return [1, 1 - r, 1 - c];
    default: throw new Error('unknown face ' + face);
  }
}

// обратное преобразование: по текущим (x,y,z) наклейки на данной грани получить (row,col)
function faceGridPos(face, x, y, z) {
  switch (face) {
    case 'U': return [z + 1, x + 1];
    case 'D': return [1 - z, x + 1];
    case 'F': return [1 - y, x + 1];
    case 'B': return [1 - y, 1 - x];
    case 'L': return [1 - y, z + 1];
    case 'R': return [1 - y, 1 - z];
    default: throw new Error('unknown face ' + face);
  }
}

export function newSolvedCube() {
  const stickers = [];
  for (const face of FACES) {
    for (let r = 0; r < 3; r++) {
      for (let c = 0; c < 3; c++) {
        const [x, y, z] = initPos(face, r, c);
        const [fx, fy, fz] = NORMAL[face];
        stickers.push({ home: face, x, y, z, fx, fy, fz });
      }
    }
  }
  return stickers;
}

// Строит кубик из "фасеточного" представления: facelets[face] = массив из 9 цветов
// (в том же порядке row-major r,c как в initPos). Цвета — произвольные строки-метки,
// главное чтобы соответствовали 6 разным центрам. Используется вводом с камеры/редактором.
export function cubeFromFacelets(facelets) {
  const stickers = [];
  for (const face of FACES) {
    const arr = facelets[face];
    if (!arr || arr.length !== 9) throw new Error('facelets: face ' + face + ' must have 9 entries');
    for (let r = 0; r < 3; r++) {
      for (let c = 0; c < 3; c++) {
        const [x, y, z] = initPos(face, r, c);
        const [fx, fy, fz] = NORMAL[face];
        stickers.push({ home: arr[r * 3 + c], x, y, z, fx, fy, fz });
      }
    }
  }
  return stickers;
}

function rotateSticker(s, face) {
  switch (face) {
    case 'R': { const y = s.y, z = s.z; s.y = z; s.z = -y; const fy = s.fy, fz = s.fz; s.fy = fz; s.fz = -fy; break; }
    case 'L': { const y = s.y, z = s.z; s.y = -z; s.z = y; const fy = s.fy, fz = s.fz; s.fy = -fz; s.fz = fy; break; }
    case 'U': { const x = s.x, z = s.z; s.x = -z; s.z = x; const fx = s.fx, fz = s.fz; s.fx = -fz; s.fz = fx; break; }
    case 'D': { const x = s.x, z = s.z; s.x = z; s.z = -x; const fx = s.fx, fz = s.fz; s.fx = fz; s.fz = -fx; break; }
    case 'F': { const x = s.x, y = s.y; s.x = y; s.y = -x; const fx = s.fx, fy = s.fy; s.fx = fy; s.fy = -fx; break; }
    case 'B': { const x = s.x, y = s.y; s.x = -y; s.y = x; const fx = s.fx, fy = s.fy; s.fx = -fy; s.fy = fx; break; }
    default: throw new Error('unknown face ' + face);
  }
}

const AXIS = { R: ['x', 1], L: ['x', -1], U: ['y', 1], D: ['y', -1], F: ['z', 1], B: ['z', -1] };

function turnOnce(cube, face) {
  const [axis, val] = AXIS[face];
  for (const s of cube) {
    if (s[axis] === val) rotateSticker(s, face);
  }
}

// применить один ход в нотации: "R", "R'", "R2", "U", ...
export function applyMove(cube, token) {
  const face = token[0];
  const mod = token.slice(1);
  let times = 1;
  if (mod === "'") times = 3;
  else if (mod === '2') times = 2;
  else if (mod !== '') throw new Error('bad move token ' + token);
  for (let i = 0; i < times; i++) turnOnce(cube, face);
}

export function applyMoves(cube, tokens) {
  for (const t of tokens) applyMove(cube, t);
}

export function inverseToken(t) {
  return t.endsWith("'") ? t[0] : (t.endsWith('2') ? t : t + "'");
}

export function inverseMoves(tokens) {
  return tokens.slice().reverse().map(inverseToken);
}

export function cloneCube(cube) {
  return cube.map((s) => ({ ...s }));
}

export function getFaceGrid(cube, face) {
  const [nx, ny, nz] = NORMAL[face];
  const grid = new Array(9).fill(null);
  for (const s of cube) {
    if (s.fx === nx && s.fy === ny && s.fz === nz) {
      const [r, c] = faceGridPos(face, s.x, s.y, s.z);
      grid[r * 3 + c] = s.home;
    }
  }
  return grid;
}

export function getAllFacelets(cube) {
  const out = {};
  for (const f of FACES) out[f] = getFaceGrid(cube, f);
  return out;
}

export function isSolved(cube) {
  for (const f of FACES) {
    const g = getFaceGrid(cube, f);
    if (!g.every((c) => c === g[0])) return false;
  }
  return true;
}

function piecesAtArity(cube, arity) {
  const byPos = new Map();
  for (const s of cube) {
    const n = Math.abs(s.x) + Math.abs(s.y) + Math.abs(s.z);
    if (n !== arity) continue;
    const key = s.x + ',' + s.y + ',' + s.z;
    if (!byPos.has(key)) byPos.set(key, []);
    byPos.get(key).push(s);
  }
  return byPos;
}

// найти пару наклеек ребра с данными двумя цветами (порядок не важен)
export function findEdge(cube, colorA, colorB) {
  const want = [colorA, colorB].sort().join('');
  for (const [, arr] of piecesAtArity(cube, 2)) {
    if (arr.length === 2 && arr.map((s) => s.home).sort().join('') === want) return arr;
  }
  return null;
}

// найти тройку наклеек угла с данными тремя цветами (порядок не важен)
export function findCorner(cube, colorA, colorB, colorC) {
  const want = [colorA, colorB, colorC].sort().join('');
  for (const [, arr] of piecesAtArity(cube, 3)) {
    if (arr.length === 3 && arr.map((s) => s.home).sort().join('') === want) return arr;
  }
  return null;
}
