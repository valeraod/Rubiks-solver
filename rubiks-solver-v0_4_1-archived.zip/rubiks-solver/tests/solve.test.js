import test from 'node:test';
import assert from 'node:assert/strict';
import path from 'path';
import { fileURLToPath } from 'url';
import * as E from '../js/engine.js';
import { loadTables, nodeFetchJson } from '../js/kociemba/tables.js';
import { solveCube } from '../js/kociemba/solve.js';
import { optimizeMoves } from '../js/kociemba/moveOptimizer.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const TABLES_DIR = path.join(__dirname, '..', 'data', 'tables');

let tables;
test.before(async () => {
  tables = await loadTables(nodeFetchJson(TABLES_DIR));
});

const MOVESET = [];
for (const f of ['U', 'D', 'L', 'R', 'F', 'B']) for (const m of ['', "'", '2']) MOVESET.push(f + m);
function randomScramble(n) {
  const a = [];
  for (let i = 0; i < n; i++) a.push(MOVESET[Math.floor(Math.random() * MOVESET.length)]);
  return a;
}

test('already-solved cube solves with zero moves', () => {
  const cube = E.newSolvedCube();
  const result = solveCube(cube, tables);
  assert.equal(result.solved, true);
  assert.deepEqual(result.moves, []);
});

test('single-move scramble solves correctly', () => {
  for (const mv of MOVESET) {
    const cube = E.newSolvedCube();
    E.applyMove(cube, mv);
    const result = solveCube(cube, tables);
    assert.equal(result.solved, true, `failed to solve after single move ${mv}`);
  }
});

test('50 random scrambles all solve, with reasonable move counts and timing', () => {
  const N = 50;
  let totalMoves = 0, maxMoves = 0, totalTime = 0, maxTime = 0;
  for (let t = 0; t < N; t++) {
    const cube = E.newSolvedCube();
    const scramble = randomScramble(30);
    E.applyMoves(cube, scramble);
    const t0 = Date.now();
    const result = solveCube(cube, tables);
    const dt = Date.now() - t0;
    totalTime += dt; maxTime = Math.max(maxTime, dt);
    assert.equal(result.solved, true, `scramble #${t} failed: ${scramble.join(' ')}`);
    totalMoves += result.moves.length; maxMoves = Math.max(maxMoves, result.moves.length);
    // sanity: re-verify solved by replaying moves on a fresh copy
    const check = E.newSolvedCube();
    E.applyMoves(check, scramble);
    E.applyMoves(check, result.moves);
    assert.equal(E.isSolved(check), true, `replayed solution did not solve scramble #${t}`);
  }
  console.log(`\n[solve.test] ${N} scrambles: avg ${(totalTime / N).toFixed(1)}ms (max ${maxTime}ms), avg ${(totalMoves / N).toFixed(1)} moves (max ${maxMoves})`);
});

test('solving from cubeFromFacelets (round-trip via facelet representation) works', () => {
  for (let t = 0; t < 10; t++) {
    const cube = E.newSolvedCube();
    E.applyMoves(cube, randomScramble(25));
    const facelets = E.getAllFacelets(cube);
    const rebuilt = E.cubeFromFacelets(facelets);
    const result = solveCube(rebuilt, tables);
    assert.equal(result.solved, true);
  }
});

test('optimizeMoves collapses adjacent same-face moves correctly', () => {
  assert.deepEqual(optimizeMoves(['U', 'U']), ['U2']);
  assert.deepEqual(optimizeMoves(['U', "U'"]), []);
  assert.deepEqual(optimizeMoves(['U', 'U2']), ["U'"]);
  assert.deepEqual(optimizeMoves(["U'", 'U2']), ['U']);
  assert.deepEqual(optimizeMoves(['U', 'R']), ['U', 'R']);
  assert.deepEqual(optimizeMoves(['R', 'U', 'U', "F'"]), ['R', 'U2', "F'"]);
});
